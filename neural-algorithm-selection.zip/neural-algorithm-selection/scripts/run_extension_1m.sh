#!/usr/bin/env bash
# 1M extension (protocols/FROZEN_1M_EXTENSION_ADDENDUM.json): resume each confirmatory
# 250k checkpoint, including AdamW state, and train to 1,000,000 steps.
# If interrupted, pass the latest *_progress.pt in the output folder as RESUME_<GROUP>.
set -euo pipefail
cd "$(dirname "$0")/.."
DEVICE=${DEVICE:-cuda}
BASE=${BASE:-results/order27_confirmatory_seed32}
OUT=${OUT:-results/order27_confirmatory_seed32_1m}
for GROUP in H27 M27; do
  g=$(echo "$GROUP" | tr '[:upper:]' '[:lower:]')
  var="RESUME_${GROUP}"
  SRC=${!var:-$BASE/$GROUP/${g}_n64_f0.70_s250000_seed32_checkpoints.pt}
  PYTHONPATH=src python -m algoselect.train \
    --resume "$SRC" --steps 1000000 --device "$DEVICE" \
    --log-every 500 --structure-every 500 --causal-every 5000 --progress-every 5000 \
    --out-dir "$OUT/$GROUP"
done
