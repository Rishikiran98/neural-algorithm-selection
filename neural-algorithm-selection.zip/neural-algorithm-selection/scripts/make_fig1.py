"""Figure 1: cumulative fraction of the 64 confirmatory models per group that reach
quotient accuracy >= 0.90 and exact accuracy >= 0.80 (first logged crossing, held-out
split). Every model stays in the denominator through 1M steps.

Inputs
  --confirm-dir   folder with H27/ and M27/ 250k confirmatory metrics CSVs
  --first-passage folder with {H27,M27}_first_passage_1m.csv (exact >= 0.80 through 1M;
                  written by notebook section 4.2, copies in results/derived/)
Outputs (in --out-dir): fig1_cumulative_criteria.{png,pdf}, fig1_first_crossings.csv
"""
import argparse
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

Q_THR, X_THR, HORIZON, N = 0.90, 0.80, 1_000_000, 64
BLUE, ORANGE = "#2a78d6", "#eb6834"
INK, MUTED, GRID = "#1a1a19", "#6b6a63", "#e6e5e0"


def first_cross(m, col, thr):
    return m[m[col] >= thr].groupby("model").step.min().reindex(range(N))


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--confirm-dir", type=Path, default=Path("results/order27_confirmatory_seed32"))
    ap.add_argument("--first-passage", type=Path, default=Path("results/derived"))
    ap.add_argument("--out-dir", type=Path, default=Path("results/derived"))
    a = ap.parse_args()
    a.out_dir.mkdir(parents=True, exist_ok=True)

    events, rows = {}, []
    for g in ["H27", "M27"]:
        m = pd.read_csv(a.confirm_dir / g / f"{g.lower()}_n64_f0.70_s250000_seed32_metrics.csv")
        assert m.model.nunique() == N and m.step.max() == 250_000
        q = first_cross(m, "test_quotient_acc", Q_THR)
        x250 = first_cross(m, "test_acc", X_THR)
        fp = pd.read_csv(a.first_passage / f"{g}_first_passage_1m.csv").set_index("model").reindex(range(N))
        x = fp.time.where(fp.event == 1)
        early = x[x <= 250_000]  # 1M first passages must agree with the 250k metrics
        assert len(early) == x250.notna().sum() and (early == x250.dropna()).all(), g
        events[g] = (q, x)
        rows.append(dict(group=g, quotient_reached=int(q.notna().sum()), quotient_median_step=q.median(),
                         exact_by_250k=int((x <= 250_000).sum()), exact_by_1m=int(x.notna().sum()),
                         quotient_first=int((q[x.notna()] < x.dropna()).sum()),
                         min_gap_steps=float((x - q).min())))
    print(pd.DataFrame(rows).to_string(index=False))
    pd.concat({g: pd.DataFrame({"quotient_step": q, "exact_step": x}) for g, (q, x) in events.items()},
              names=["group", "model"]).to_csv(a.out_dir / "fig1_first_crossings.csv")

    grid = np.arange(500, HORIZON + 1, 500)
    cum = lambda t: np.searchsorted(np.sort(t.dropna().to_numpy()), grid, side="right") / N
    plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 10})
    fig, axes = plt.subplots(1, 2, figsize=(11, 3.9), sharey=True)
    for ax, g in zip(axes, ["H27", "M27"]):
        q, x = events[g]
        yq, yx = cum(q), cum(x)
        ax.step(grid, yq, where="post", color=BLUE, lw=2)
        ax.step(grid, yx, where="post", color=ORANGE, lw=2, ls=(0, (5, 2)))
        ax.axvline(250_000, color=MUTED, lw=1, ls=":")
        ax.text(250_000 * 1.08, 0.04, "frozen 250k\nhorizon", color=MUTED, fontsize=8, va="bottom")
        nq, nx, n250 = int(q.notna().sum()), int(x.notna().sum()), int((x <= 250_000).sum())
        ax.text(1.6e4, 0.92, f"quotient acc ≥ {Q_THR:.2f}\n{nq}/{N} models\nmedian {q.median():,.0f} steps",
                color=BLUE, fontsize=8.5, va="top")
        ax.text(1.1e4, 0.45, f"exact acc ≥ {X_THR:.2f}\n{n250}/{N} by 250k\n{nx}/{N} by 1M",
                color=ORANGE, fontsize=8.5, va="bottom")
        ax.annotate("", xy=(1.12e6, yx[-1]), xytext=(1.12e6, 1.0), annotation_clip=False,
                    arrowprops=dict(arrowstyle="<->", color=MUTED, lw=1, shrinkA=0, shrinkB=0))
        ax.text(1.22e6, (yx[-1] + 1) / 2, f"{N - nx}/{N}\nnever reach\nexact ≥ {X_THR:.2f}\nby 1M",
                color=MUTED, fontsize=8, ha="left", va="center", clip_on=False)
        ax.set_xscale("log"); ax.set_xlim(500, HORIZON); ax.set_ylim(0, 1.02)
        ax.set_xticks([1e3, 1e4, 1e5, 1e6], ["1k", "10k", "100k", "1M"])
        ax.set_title(g, color=INK, fontsize=11, loc="left", fontweight="bold")
        ax.set_xlabel("Training step (log scale)", color=INK)
        ax.grid(axis="y", color=GRID, lw=0.8)
        for s in ["top", "right"]:
            ax.spines[s].set_visible(False)
        for s in ["left", "bottom"]:
            ax.spines[s].set_color(MUTED)
        ax.tick_params(colors=MUTED)
    axes[0].set_ylabel(f"Fraction of {N} models\nthat have reached criterion", color=INK)
    fig.tight_layout(); fig.subplots_adjust(right=0.9, wspace=0.32)
    for ext in ["png", "pdf"]:
        fig.savefig(a.out_dir / f"fig1_cumulative_criteria.{ext}", dpi=200)


if __name__ == "__main__":
    main()
