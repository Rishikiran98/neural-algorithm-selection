#!/usr/bin/env bash
# Discovery cohort (exploratory): init seeds 0-31, split seed 100000, 32 models per group.
# Trains to 100k, then resumes the same optimizer state to 250k (see run_order27_decisive.sh).
set -euo pipefail
cd "$(dirname "$0")/.."
DEVICE=${DEVICE:-cuda} MODELS=32 FRAC=0.70 INITIAL_STEPS=100000 FULL_STEPS=250000 \
OUT=${OUT:-results/order27_gpu} \
  bash scripts/run_order27_decisive.sh 2>&1 | tee -a order27_decisive.log
