#!/usr/bin/env bash
# Confirmatory cohort (protocols/FROZEN_CONFIRMATORY_PROTOCOL.json):
# init seeds 32-95, one shared split (seed 100032), 64 models per group, 250k steps.
# Do NOT pass --different-splits: every model must share split seed 100032.
set -euo pipefail
cd "$(dirname "$0")/.."
DEVICE=${DEVICE:-cuda}
OUT=${OUT:-results/order27_confirmatory_seed32}
for GROUP in H27 M27; do
  PYTHONPATH=src python -m algoselect.train \
    --group "$GROUP" --num-models 64 --seed-base 32 \
    --train-fraction 0.70 --d-embed 256 --d-hidden 128 \
    --steps 250000 --lr 1e-3 --weight-decay 1.0 --beta1 0.9 --beta2 0.98 \
    --device "$DEVICE" \
    --log-every 500 --structure-every 500 --causal-every 5000 --progress-every 5000 \
    --out-dir "$OUT/$GROUP"
done
