"""Appendix A: trace the H27 slope discrepancy (0.036 in notebook cell 77 vs 0.065 in cell 81).

Both fit, per eventual-success model, ablated exact accuracy (base + rho3 delta) on intact
exact accuracy, from the same merged 250k + 1M causal trajectories (5,000-step cadence),
and report the median per-model slope. They differ only in the window on intact accuracy.

Inputs
  --confirm-dir    folder with H27/ and M27/ 250k *_causal_trajectory.csv
  --ext-dir        folder with H27/ and M27/ 1M *_causal_trajectory.csv
  --first-passage  folder with {H27,M27}_first_passage_1m.csv (results/derived/)
Output: slope_trace.csv in --out-dir
"""
import argparse
from pathlib import Path

import numpy as np
import pandas as pd

A0 = {"H27": 0.146, "M27": 0.091}  # quotient-only floor: median final exact acc of stalled models (cell 77)


def load(a, g):
    old = pd.read_csv(next((a.confirm_dir / g).glob("*s250000*_causal_trajectory.csv")))
    new = pd.read_csv(next((a.ext_dir / g).glob("*s1000000*_causal_trajectory.csv")))
    c = (pd.concat([old, new]).sort_values(["model", "step", "component"])
         .drop_duplicates(["model", "step", "component"], keep="last"))
    z = c[c.component.str.contains("rho3")].copy()
    assert not z.duplicated(["model", "step"]).any()
    z["A_base"] = z.base_test_acc
    z["A_abl"] = z.base_test_acc + z.test_acc_delta
    fp = pd.read_csv(a.first_passage / f"{g}_first_passage_1m.csv")
    return z, fp[fp.event == 1].set_index("model").time


def slopes(z, succ, lo, hi, rise_only=False):
    rows = []
    for mdl, t in succ.items():
        g = z[z.model == mdl]
        w = g[(g.A_base >= lo) & (g.A_base <= hi)]
        if rise_only:
            w = w[w.step < t]
        if len(w) < 3 or np.ptp(w.A_base) < 1e-9:
            continue
        rows.append(dict(model=mdl, n=len(w), slope=np.polyfit(w.A_base, w.A_abl, 1)[0],
                         n_after_success=int((w.step >= t).sum())))
    return pd.DataFrame(rows)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--confirm-dir", type=Path, default=Path("results/order27_confirmatory_seed32"))
    ap.add_argument("--ext-dir", type=Path, default=Path("results/order27_confirmatory_seed32_1m"))
    ap.add_argument("--first-passage", type=Path, default=Path("results/derived"))
    ap.add_argument("--out-dir", type=Path, default=Path("results/derived"))
    ap.add_argument("--boot", type=int, default=10000)
    a = ap.parse_args()
    rng = np.random.default_rng(0)
    out = []
    for g in ["H27", "M27"]:
        z, succ = load(a, g)
        lo_narrow = max(A0[g] + 0.05, 0.15)
        for name, lo, hi, rise in [
            ("cell 77 window [max(A0+.05,.15), .80] (reported)", lo_narrow, 0.80, False),
            ("cell 81 window [.10, .95]", 0.10, 0.95, False),
            ("cell 81 window, before first 0.80 crossing", 0.10, 0.95, True),
        ]:
            s = slopes(z, succ, lo, hi, rise)
            b = [np.median(rng.choice(s.slope, len(s))) for _ in range(a.boot)]
            lo_ci, hi_ci = np.percentile(b, [2.5, 97.5])
            out.append(dict(group=g, window=name, models=len(s), median_points=s.n.median(),
                            median_slope=s.slope.median(), ci_low=lo_ci, ci_high=hi_ci,
                            median_points_after_success=s.n_after_success.median()))
    df = pd.DataFrame(out)
    print(df.to_string(index=False))
    a.out_dir.mkdir(parents=True, exist_ok=True)
    df.to_csv(a.out_dir / "slope_trace.csv", index=False)


if __name__ == "__main__":
    main()
