#!/usr/bin/env bash
set -euo pipefail

DEVICE=${DEVICE:-cuda}
MODELS=${MODELS:-32}
STEPS=${STEPS:-250000}
OUT=${OUT:-results/phase_minus_one}
PROGRESS_EVERY=${PROGRESS_EVERY:-10000}
LOG_EVERY=${LOG_EVERY:-1000}

for GROUP in H27 D8; do
  for FRAC in 0.30 0.40 0.50 0.70; do
    echo "=== ${GROUP} train_fraction=${FRAC} ==="
    PYTHONPATH=src python -m algoselect.train \
      --group "$GROUP" \
      --num-models "$MODELS" \
      --train-fraction "$FRAC" \
      --steps "$STEPS" \
      --device "$DEVICE" \
      --log-every "$LOG_EVERY" \
      --structure-every "$LOG_EVERY" \
      --progress-every "$PROGRESS_EVERY" \
      --out-dir "$OUT"
  done
done
