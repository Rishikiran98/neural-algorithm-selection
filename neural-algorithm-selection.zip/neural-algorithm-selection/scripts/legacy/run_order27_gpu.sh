#!/usr/bin/env bash
set -euo pipefail

DEVICE=${DEVICE:-cuda}
MODELS=${MODELS:-32}
STEPS=${STEPS:-100000}
FRAC=${FRAC:-0.70}
OUT=${OUT:-results/order27_gpu}
LOG_EVERY=${LOG_EVERY:-500}
STRUCTURE_EVERY=${STRUCTURE_EVERY:-500}
CAUSAL_EVERY=${CAUSAL_EVERY:-5000}
PROGRESS_EVERY=${PROGRESS_EVERY:-5000}
ALG_GROUPS=${ALG_GROUPS:-"H27 M27"}

for GROUP in $ALG_GROUPS; do
  echo "=== ${GROUP}: models=${MODELS}, fraction=${FRAC}, steps=${STEPS} ==="
  PYTHONPATH=src python -m algoselect.train \
    --group "$GROUP" \
    --num-models "$MODELS" \
    --train-fraction "$FRAC" \
    --d-embed 256 \
    --d-hidden 128 \
    --steps "$STEPS" \
    --lr 1e-3 \
    --weight-decay 1.0 \
    --beta1 0.9 \
    --beta2 0.98 \
    --device "$DEVICE" \
    --log-every "$LOG_EVERY" \
    --structure-every "$STRUCTURE_EVERY" \
    --causal-every "$CAUSAL_EVERY" \
    --progress-every "$PROGRESS_EVERY" \
    --out-dir "$OUT/$GROUP"
done
