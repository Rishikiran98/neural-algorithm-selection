#!/usr/bin/env bash
set -euo pipefail

DEVICE=${DEVICE:-cuda}
MODELS=${MODELS:-32}
FRAC=${FRAC:-0.70}
INITIAL_STEPS=${INITIAL_STEPS:-100000}
FULL_STEPS=${FULL_STEPS:-250000}
EXACT_THRESHOLD=${EXACT_THRESHOLD:-0.99}
OUT=${OUT:-results/order27_gpu}
LOG_EVERY=${LOG_EVERY:-500}
STRUCTURE_EVERY=${STRUCTURE_EVERY:-500}
CAUSAL_EVERY=${CAUSAL_EVERY:-5000}
PROGRESS_EVERY=${PROGRESS_EVERY:-5000}
ALG_GROUPS=${ALG_GROUPS:-"H27 M27"}

run_fresh() {
  local group=$1 target=$2 out_dir=$3
  PYTHONPATH=src python -m algoselect.train \
    --group "$group" \
    --num-models "$MODELS" \
    --train-fraction "$FRAC" \
    --d-embed 256 \
    --d-hidden 128 \
    --steps "$target" \
    --lr 1e-3 \
    --weight-decay 1.0 \
    --beta1 0.9 \
    --beta2 0.98 \
    --device "$DEVICE" \
    --log-every "$LOG_EVERY" \
    --structure-every "$STRUCTURE_EVERY" \
    --causal-every "$CAUSAL_EVERY" \
    --progress-every "$PROGRESS_EVERY" \
    --out-dir "$out_dir"
}

resume_to() {
  local checkpoint=$1 target=$2 out_dir=$3
  PYTHONPATH=src python -m algoselect.train \
    --resume "$checkpoint" \
    --steps "$target" \
    --device "$DEVICE" \
    --log-every "$LOG_EVERY" \
    --structure-every "$STRUCTURE_EVERY" \
    --causal-every "$CAUSAL_EVERY" \
    --progress-every "$PROGRESS_EVERY" \
    --out-dir "$out_dir"
}

is_complete() {
  local metrics=$1 threshold=$2 expected_models=$3
  python - "$metrics" "$threshold" "$expected_models" <<'PY'
import sys
import pandas as pd
path, threshold, expected = sys.argv[1], float(sys.argv[2]), int(sys.argv[3])
df = pd.read_csv(path)
last = df[df.step == df.step.max()].sort_values('model')
if len(last) != expected:
    print(f"incomplete metrics: expected {expected} models, found {len(last)}", file=sys.stderr)
    raise SystemExit(1)
vals = last.test_acc.astype(float)
print(f"final step={int(last.step.iloc[0])} exact held-out: mean={vals.mean():.4f} min={vals.min():.4f} max={vals.max():.4f}; threshold={threshold:.4f}")
raise SystemExit(0 if (vals >= threshold).all() else 2)
PY
}

for GROUP in $ALG_GROUPS; do
  glower=$(printf '%s' "$GROUP" | tr '[:upper:]' '[:lower:]')
  group_out="$OUT/$GROUP"
  mkdir -p "$group_out"

  initial_stem="${glower}_n${MODELS}_f$(printf '%.2f' "$FRAC")_s${INITIAL_STEPS}_seed0"
  initial_ckpt="$group_out/${initial_stem}_checkpoints.pt"
  initial_progress="$group_out/${initial_stem}_progress.pt"
  initial_metrics="$group_out/${initial_stem}_metrics.csv"

  echo "=== $GROUP: target ${INITIAL_STEPS} steps, models=${MODELS}, fraction=${FRAC} ==="
  if [[ -f "$initial_ckpt" ]]; then
    echo "Using completed ${INITIAL_STEPS}-step checkpoint: $initial_ckpt"
  elif [[ -f "$initial_progress" ]]; then
    echo "Resuming interrupted run from: $initial_progress"
    resume_to "$initial_progress" "$INITIAL_STEPS" "$group_out"
  else
    run_fresh "$GROUP" "$INITIAL_STEPS" "$group_out"
  fi

  set +e
  is_complete "$initial_metrics" "$EXACT_THRESHOLD" "$MODELS"
  status=$?
  set -e
  if [[ $status -eq 0 ]]; then
    echo "$GROUP exact generalization complete at ${INITIAL_STEPS}; no extension required."
    continue
  elif [[ $status -ne 2 ]]; then
    echo "Could not evaluate $GROUP completion from $initial_metrics" >&2
    exit $status
  fi

  final_stem="${glower}_n${MODELS}_f$(printf '%.2f' "$FRAC")_s${FULL_STEPS}_seed0"
  final_ckpt="$group_out/${final_stem}_checkpoints.pt"
  final_progress="$group_out/${final_stem}_progress.pt"
  final_metrics="$group_out/${final_stem}_metrics.csv"

  echo "$GROUP exact generalization incomplete at ${INITIAL_STEPS}; extending to ${FULL_STEPS}."
  if [[ -f "$final_ckpt" ]]; then
    echo "Using completed ${FULL_STEPS}-step checkpoint: $final_ckpt"
  elif [[ -f "$final_progress" ]]; then
    resume_to "$final_progress" "$FULL_STEPS" "$group_out"
  else
    resume_to "$initial_ckpt" "$FULL_STEPS" "$group_out"
  fi

  set +e
  is_complete "$final_metrics" "$EXACT_THRESHOLD" "$MODELS"
  final_status=$?
  set -e
  if [[ $final_status -eq 0 ]]; then
    echo "$GROUP exact generalization complete by ${FULL_STEPS}."
  elif [[ $final_status -eq 2 ]]; then
    echo "$GROUP remains incomplete at ${FULL_STEPS}; preserve final checkpoint for analysis."
  else
    exit $final_status
  fi
done
