# What Selects a Neural Algorithm?

Experimental code for studying causal mechanism choice in group-composition networks.

## Scientific target

The project asks what determines which internal algorithmic mechanism a network converges to when multiple exact solutions exist. The planned matched-algebra comparison uses:

- `D8` vs `Q8`: matched complex character dimensions but different Frobenius-Schur type for the faithful 2D irrep.
- `H27` vs `M27`: non-isomorphic order-27 groups with matched irrep dimensions and matched complex type for the nonlinear 3D irreps.

The current milestone is **Phase -1: task viability**. We require nontrivial held-out generalization, measurable representation structure, and a causal ablation effect before building the full mechanism-fingerprint pipeline.

## What is implemented

- Exact multiplication tables for `D8`, `Q8`, `H27`, `M27`.
- Group-axiom, exponent, and involution checks.
- Irreducible characters for all four groups.
- Frobenius-Schur indicators.
- Central projectors and real-stable isotypic blocks. Complex-conjugate irreps are paired before real-network ablations.
- Tensorized independent-seed group-composition MLPs.
- Separate initialization and split seeds.
- Train/test loss and exact accuracy trajectories.
- Center-quotient `G/Z(G)` accuracy and exact accuracy conditional on a correct quotient prediction.
- Per-model parameter norms.
- Irrep/block energy trajectories for left input, right input, and unembedding pathways.
- A continuous `structure_score`, measuring deviation from isotropic representation energy.
- Automatic `t_mem`, `t_structure`, and `t_gen` detection.
- Causal block-ablation trajectories, including quotient-accuracy effects.
- Rank-corrected mechanism fingerprints and seed-level Jensen-Shannon divergence.
- Resumable model + AdamW checkpoints.
- Plotting and run summaries.
- Machine-generated algebra manifest.

## Install and tests

```bash
pip install -e .
pytest
```

Current suite: 28 tests.

## Generate the algebra manifest

```bash
python -m algoselect.group_manifest --out results/group_manifest.json
```

This records group order, exponent, involution count, irrep dimensions, Frobenius-Schur indicators, and real-stable projector ranks.

## Reference-width H27 run

```bash
PYTHONPATH=src python -m algoselect.train \
  --group H27 \
  --num-models 16 \
  --train-fraction 0.40 \
  --d-embed 256 \
  --d-hidden 128 \
  --steps 250000 \
  --lr 1e-3 \
  --weight-decay 1.0 \
  --beta1 0.9 \
  --beta2 0.98 \
  --device cuda \
  --log-every 1000 \
  --structure-every 1000 \
  --progress-every 10000 \
  --out-dir results/h27_reference
```

`--progress-every` writes a resumable `*_progress.pt` plus trajectory CSVs during the run.

Resume an interrupted run to a larger target horizon:

```bash
PYTHONPATH=src python -m algoselect.train \
  --resume results/h27_reference/..._progress.pt \
  --steps 250000 \
  --device cuda \
  --out-dir results/h27_reference
```

The resume path reloads both model and AdamW state and preserves previous trajectory rows.

## Screen a completed run

```bash
PYTHONPATH=src python -m algoselect.screen \
  results/..._metrics.csv \
  --structure-summary results/..._structure_summary.csv \
  --mechanism results/..._mechanism.csv \
  --out results/..._timeline.csv
```

The engineering gate currently requires:

1. at least 25% of seeds to exceed 90% held-out accuracy,
2. sustained representation concentration above the initialization-calibrated structure threshold,
3. at least one real-stable block ablation to increase held-out loss substantially.

These are stop/go gates, not significance tests.

## Plot a run

```bash
PYTHONPATH=src python -m algoselect.analyze \
  --metrics results/..._metrics.csv \
  --structure-summary results/..._structure_summary.csv \
  --out-dir results/.../figures
```

This produces separate accuracy and structure-trajectory figures plus a JSON summary.

## Current CPU diagnostic

A reference-width `H27` run with two initialization seeds and 40% training data was followed to 5,000 steps.

Observed so far:

- both seeds reach 100% train accuracy very early,
- held-out accuracy remains 0% at 5,000 steps,
- representation concentration continues to increase long after memorization,
- one seed crosses the conservative automatic structure-onset threshold around step 2,750 and the second reaches the threshold region by the end of the run,
- no causal Phase -1 claim is made yet because held-out generalization has not appeared.

This is consistent with a long post-memorization feature-organization period, but the 5k run is only a diagnostic. The actual viability decision requires a much longer GPU trajectory.

## New Phase -1 finding

The 70% order-27 diagnostics reveal strong structured generalization before exact grokking. By 10k steps, two `H27` seeds reach about 91% mean held-out accuracy on the center quotient `G/Z(G)` while exact accuracy remains below 8%. `M27` shows a closely matched quotient trajectory through 5k.

Causal ablations separate the roles of the representation blocks: linear-character blocks are necessary for quotient generalization but have little effect on memorized training loss, while ablating the nonlinear 3D block strongly damages training performance and improves quotient accuracy to 100% in the tested seeds. See `PRELIMINARY_RESULTS.md` for the numerical diagnostics and cautions.

## Immediate next experiment

Run the matched order-27 pair with 32 seeds at 70% training data:

```bash
MODELS=32 STEPS=100000 FRAC=0.70 DEVICE=cuda ./run_order27_gpu.sh
```

If exact generalization remains incomplete, resume the same optimizer states to 250k. The next statistical target is whether the shared quotient-learning trajectory is stable across seeds and whether `H27` and `M27` diverge specifically in the nonlinear/central-extension stage.
