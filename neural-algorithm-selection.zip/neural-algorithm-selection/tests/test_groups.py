import pytest
from algoselect.groups import make_group


@pytest.mark.parametrize("name,order", [("D8",8),("Q8",8),("H27",27),("M27",27)])
def test_group_axioms(name, order):
    g = make_group(name)
    assert g.order == order
    S = set(g.elements)
    for a in g.elements:
        assert g.mul(a, g.identity) == a
        assert g.mul(g.identity, a) == a
        assert g.inv(a) in S
        for b in g.elements:
            assert g.mul(a,b) in S
            for c in g.elements:
                assert g.mul(g.mul(a,b),c) == g.mul(a,g.mul(b,c))


def test_d8_q8_involutions_separate_real_type_pair():
    d8 = make_group("D8")
    q8 = make_group("Q8")
    assert sum(d8.mul(g,g) == d8.identity for g in d8.elements) == 6
    assert sum(q8.mul(g,g) == q8.identity for g in q8.elements) == 2


def test_order27_exponents():
    h = make_group("H27")
    m = make_group("M27")
    assert max(h.element_order(g) for g in h.elements) == 3
    assert max(m.element_order(g) for g in m.elements) == 9


def test_center_quotients_have_expected_sizes():
    from algoselect.groups import make_group
    expected = {'D8': (2, 4), 'Q8': (2, 4), 'H27': (3, 9), 'M27': (3, 9)}
    for name, (z_order, q_order) in expected.items():
        g = make_group(name)
        assert len(g.center()) == z_order
        labels = g.center_quotient_labels()
        assert len(set(labels)) == q_order
        assert len(labels) == g.order
