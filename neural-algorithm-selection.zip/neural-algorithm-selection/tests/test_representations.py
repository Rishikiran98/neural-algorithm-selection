import numpy as np
import pytest

from algoselect.groups import make_group
from algoselect.representations import (
    central_projectors,
    character_inner_products,
    frobenius_schur_indicators,
    real_isotypic_blocks,
)


@pytest.mark.parametrize("name", ["D8", "Q8", "H27", "M27"])
def test_characters_are_orthonormal(name):
    g = make_group(name)
    _, gram = character_inner_products(g)
    assert np.allclose(gram, np.eye(len(gram)), atol=1e-8)


@pytest.mark.parametrize("name", ["D8", "Q8", "H27", "M27"])
def test_central_projectors_partition_regular_representation(name):
    g = make_group(name)
    ps = central_projectors(g)
    total = np.zeros((g.order, g.order), dtype=np.complex128)
    for p in ps.values():
        assert np.allclose(p @ p, p, atol=1e-8)
        total += p
    assert np.allclose(total, np.eye(g.order), atol=1e-8)


@pytest.mark.parametrize("name", ["D8", "Q8", "H27", "M27"])
def test_real_blocks_partition_regular_representation(name):
    g = make_group(name)
    ps = real_isotypic_blocks(g)
    total = np.zeros((g.order, g.order), dtype=np.float64)
    for p in ps.values():
        assert np.max(np.abs(np.imag(p))) == 0
        assert np.allclose(p @ p, p, atol=1e-8)
        total += p
    assert np.allclose(total, np.eye(g.order), atol=1e-8)


def test_fs_indicators_separate_d8_q8_and_match_order27_complex_type():
    d8 = frobenius_schur_indicators(make_group("D8"))
    q8 = frobenius_schur_indicators(make_group("Q8"))
    h27 = frobenius_schur_indicators(make_group("H27"))
    m27 = frobenius_schur_indicators(make_group("M27"))

    assert d8["rho2_real"] == 1
    assert q8["rho2_quaternionic"] == -1
    assert h27["rho3_k1"] == 0 and h27["rho3_k2"] == 0
    assert m27["rho3_orbit1"] == 0 and m27["rho3_orbit2"] == 0
