import torch

from algoselect.groups import make_group
from algoselect.model import EnsembleGroupMLP
from algoselect.retro_metrics import retroactive_metrics


def test_retroactive_metrics_reads_snapshot(tmp_path):
    g = make_group('D8')
    m = EnsembleGroupMLP(1, g.order, 8, 8, [0])
    left, right, unembed = m.effective_tables()
    payload = {
        'config': {
            'group': 'D8', 'num_models': 1, 'train_fraction': 0.5,
            'seed_base': 0, 'same_split': True,
        },
        'checkpoints': {0: {
            'effective_left': left.detach(), 'effective_right': right.detach(),
            'unembedding': unembed.detach(),
        }},
    }
    p = tmp_path / 'x.pt'; torch.save(payload, p)
    df = retroactive_metrics(p)
    assert len(df) == 1
    assert 'test_quotient_acc' in df.columns
    assert 0 <= df.iloc[0].test_quotient_acc <= 1
