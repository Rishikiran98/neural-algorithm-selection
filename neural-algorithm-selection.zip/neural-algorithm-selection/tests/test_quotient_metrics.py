import torch
from algoselect.model import per_model_quotient_accuracy, per_model_exact_given_quotient


def test_quotient_metrics_distinguish_coset_from_exact():
    # Classes 0,1 lie in quotient class A; 2,3 in B.
    q = torch.tensor([0, 0, 1, 1])
    labels = torch.tensor([0, 2])
    logits = torch.tensor([[[0., 5., 0., 0.], [0., 0., 0., 5.]]])
    mask = torch.tensor([[True, True]])
    qa = per_model_quotient_accuracy(logits, labels, mask, q)
    cond = per_model_exact_given_quotient(logits, labels, mask, q)
    assert torch.allclose(qa, torch.tensor([1.0]))
    assert torch.allclose(cond, torch.tensor([0.0]))
