import numpy as np
import pandas as pd

from algoselect.analyze import mechanism_fingerprints, seed_divergence, fingerprint_drift


def test_rank_corrected_fingerprint_is_uniform_at_isotropy(tmp_path):
    rows = []
    expected = {'a': 0.2, 'b': 0.8}
    for model in (0, 1):
        for table in ('left', 'right', 'unembed'):
            for block, e in expected.items():
                rows.append({
                    'model': model, 'step': 0, 'table': table, 'block': block,
                    'energy': e, 'isotropic_expected_energy': e,
                })
    p = tmp_path / 's.csv'
    pd.DataFrame(rows).to_csv(p, index=False)
    fp = mechanism_fingerprints(p)
    assert np.allclose(fp.fingerprint_weight.to_numpy(), 0.5)


def test_seed_divergence_zero_for_identical_fingerprints(tmp_path):
    rows = []
    for model in (0, 1):
        for table in ('left', 'right', 'unembed'):
            for block, e in (('a', 0.25), ('b', 0.75)):
                rows.append({
                    'model': model, 'step': 0, 'table': table, 'block': block,
                    'energy': e, 'isotropic_expected_energy': e,
                })
    p = tmp_path / 's.csv'
    pd.DataFrame(rows).to_csv(p, index=False)
    fp = mechanism_fingerprints(p)
    div = seed_divergence(fp)
    pair = div[div.record_type == 'pair']
    assert len(pair) == 1
    assert pair.iloc[0].js_divergence < 1e-12
    drift = fingerprint_drift(fp)
    assert np.allclose(drift.js_from_init, 0)
