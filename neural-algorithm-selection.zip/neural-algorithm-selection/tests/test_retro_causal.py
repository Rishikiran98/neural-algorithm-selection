import torch

from algoselect.data import composition_dataset, make_split_masks
from algoselect.groups import make_group
from algoselect.model import EnsembleGroupMLP
from algoselect.retro_causal import retroactive_causal_trajectory


def test_retroactive_causal_reads_effective_snapshot(tmp_path):
    group = make_group('D8')
    model = EnsembleGroupMLP(2, group.order, 8, 8, [0, 1])
    left, right, unembed = model.effective_tables()
    payload = {
        'config': {
            'group': 'D8', 'num_models': 2, 'train_fraction': 0.5,
            'd_embed': 8, 'd_hidden': 8, 'steps': 0, 'lr': 1e-3,
            'weight_decay': 1.0, 'betas': [0.9, 0.98], 'seed_base': 0,
            'same_split': True,
        },
        'checkpoints': {0: {
            'effective_left': left.detach(),
            'effective_right': right.detach(),
            'unembedding': unembed.detach(),
        }},
    }
    p = tmp_path / 'c.pt'
    torch.save(payload, p)
    df = retroactive_causal_trajectory(p)
    assert not df.empty
    assert set(df.step) == {0}
    assert set(df.model) == {0, 1}
    assert {'train_loss_delta', 'test_loss_delta'} <= set(df.columns)
