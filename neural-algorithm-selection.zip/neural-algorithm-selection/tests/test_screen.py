import pandas as pd

from algoselect.screen import summarize_metrics, summarize_structure


def test_screen_detects_memorize_then_generalize(tmp_path):
    rows = []
    for m in range(2):
        for step, tr, te in [(0, .1, .1), (10, 1.0, .2), (20, 1.0, .95)]:
            rows.append({
                "model": m, "step": step, "train_acc": tr, "test_acc": te,
                "train_loss": 1-tr, "test_loss": 1-te,
            })
    p = tmp_path / "m.csv"
    pd.DataFrame(rows).to_csv(p, index=False)
    per, s = summarize_metrics(p)
    assert s["memorized_fraction"] == 1.0
    assert s["generalized_fraction"] == 1.0
    assert (per.grok_delay == 10).all()


def test_structure_screen_requires_persistent_shift(tmp_path):
    rows = []
    # t=0 baseline .02/.03. Model 0 crosses persistently at 20. Model 1 has one spike only.
    vals = {
        0: [(0, .02), (10, .03), (20, .20), (30, .22)],
        1: [(0, .03), (10, .25), (20, .04), (30, .05)],
    }
    for m, seq in vals.items():
        for step, score in seq:
            for table in ("left", "right", "unembed"):
                rows.append({"model": m, "step": step, "table": table, "structure_score": score})
    p = tmp_path / "s.csv"
    pd.DataFrame(rows).to_csv(p, index=False)
    per, s = summarize_structure(p, min_delta=.05, robust_z=0, persistence=2)
    assert per.loc[per.model == 0, "t_structure"].iloc[0] == 20
    assert pd.isna(per.loc[per.model == 1, "t_structure"].iloc[0])
    assert s["structured_fraction"] == .5


def test_summarize_metrics_detects_post_mem_test_loss_peak(tmp_path):
    import pandas as pd
    from algoselect.screen import summarize_metrics
    rows = []
    for step, tr, te_loss in [(0, 0.1, 3.0), (10, 1.0, 8.0), (20, 1.0, 10.0), (30, 1.0, 7.0)]:
        rows.append({
            'model': 0, 'step': step, 'train_acc': tr, 'test_acc': 0.0,
            'train_loss': 0.0, 'test_loss': te_loss,
        })
    p = tmp_path / 'm.csv'
    pd.DataFrame(rows).to_csv(p, index=False)
    per, summary = summarize_metrics(p)
    assert int(per.iloc[0].t_test_loss_peak) == 20
    assert per.iloc[0].cleanup_loss_drop == 3.0
    assert summary['median_t_test_loss_peak'] == 20.0
