# Quotient Generalization Precedes Selective Exact Generalization in Two Non-Abelian Groups

Code, frozen protocols and analysis notebook for the paper. Small one-hidden-layer MLPs learn composition in the two non-isomorphic non-abelian groups of order 27, H27 (exponent 3) and M27 (exponent 9). The groups share a character table, a center Z ≅ Z3 and a quotient G/Z ≅ Z3 × Z3.

Main result, confirmatory cohort (64 networks per group, one shared train/test split):

| | H27 | M27 |
| --- | --- | --- |
| Held-out quotient accuracy ≥ 0.90 (median step) | 64/64 (5,500) | 64/64 (5,500) |
| Held-out exact accuracy ≥ 0.80 by 250k steps | 21/64 | 18/64 |
| Held-out exact accuracy ≥ 0.80 by 1M steps | 26/64 | 25/64 |
| Quotient criterion reached first, among 1M successes (shortest gap) | 26/26 (37,000 steps) | 25/25 (48,500 steps) |

## Repository layout

```
src/algoselect/        groups, isotypic projectors, model, training, causal ablations
tests/                 unit tests (28)
protocols/             frozen confirmatory protocol and 1M addendum (+ SHA-256)
scripts/
  run_discovery.sh       discovery cohort: seeds 0-31, split 100000, 250k steps
  run_confirmatory.sh    confirmatory cohort: seeds 32-95, split 100032, 250k steps
  run_extension_1m.sh    resume confirmatory checkpoints (with AdamW state) to 1M steps
  run_order27_decisive.sh  100k -> 250k driver used by run_discovery.sh
  make_fig1.py           Figure 1 (cumulative quotient / exact criteria)
  slope_trace.py         Appendix A slope-window recomputation
  legacy/                earlier pilot scripts, not used in the paper
notebooks/
  grokking_analysis.ipynb        every analysis in the paper, with saved outputs
  sample_size_sweep_archive.ipynb  unfinished sample-size sweep (no results reported)
results/derived/       small derived files: first-passage times, Figure 1, slope trace
docs/PROJECT_HISTORY.md  original project README from the pilot phase
```

## Setup

Python ≥ 3.10.

```bash
pip install -e .
pytest            # 28 tests
```

Training was run on a single Colab GPU. Each model in a cohort is trained as part of one vectorized ensemble.

## Reproduce the runs

```bash
DEVICE=cuda bash scripts/run_discovery.sh       # results/order27_gpu/
DEVICE=cuda bash scripts/run_confirmatory.sh    # results/order27_confirmatory_seed32/
DEVICE=cuda bash scripts/run_extension_1m.sh    # results/order27_confirmatory_seed32_1m/
```

Training settings for every run: AdamW, learning rate 1e-3, weight decay 1.0, β = (0.9, 0.98), full-batch cross-entropy, embedding width 256, hidden width 128, 70% training split (510 of 729 pairs). Metrics are logged every 500 steps and ablation effects every 5,000 steps.

Numerical results depend on hardware. A 1,000-step CPU run of seeds 32–33 matches the saved GPU run's exact accuracy and is within 0.03 on quotient accuracy. Results are not bitwise identical.

## Reproduce the analyses

`notebooks/grokking_analysis.ipynb` contains every analysis in the paper. Its saved outputs are the source of every reported number, and each code cell is labelled with its original cell number. It expects the repository and results on Google Drive at `MyDrive/neural_algorithm_selection/neural-algorithm-selection`; change `REPO` in the setup cell to run elsewhere.

The two standalone scripts reproduce Figure 1 and the Appendix A check:

```bash
python scripts/make_fig1.py   --confirm-dir results/order27_confirmatory_seed32
python scripts/slope_trace.py --confirm-dir results/order27_confirmatory_seed32 \
                              --ext-dir results/order27_confirmatory_seed32_1m
```

## Protocols

Predictions P1–P7 and all thresholds were fixed in `protocols/FROZEN_CONFIRMATORY_PROTOCOL.json` after the exploratory discovery runs and before the confirmatory cohort was trained. The 1M extension follows `protocols/FROZEN_1M_EXTENSION_ADDENDUM.json`, which was fixed before any extended results existed. Check its hash with:

```bash
sha256sum protocols/FROZEN_1M_EXTENSION_ADDENDUM.json
cat protocols/FROZEN_1M_EXTENSION_ADDENDUM.sha256
```

The trainer used for all reported runs, `src/algoselect/train.py`, has SHA-256 `a656a6de…6e179`.

## Data

Raw training outputs (per-checkpoint metrics, causal trajectories and model checkpoints) are too large for git and are not included. `results/derived/` holds the small files needed to redraw Figure 1. Rerunning the scripts above regenerates the rest.
