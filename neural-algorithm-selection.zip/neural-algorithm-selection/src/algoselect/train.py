from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
import torch

from .data import composition_dataset, make_split_masks
from .groups import make_group
from .model import (
    EnsembleGroupMLP,
    per_model_accuracy,
    per_model_losses,
    per_model_quotient_accuracy,
    per_model_exact_given_quotient,
)
from .representations import (
    ablate_group_component,
    embedding_isotypic_energy,
    real_isotypic_blocks,
)


def _is_trivial_block(group_name: str, block_name: str) -> bool:
    return block_name in {
        "chi_r+1_s+1",  # D8
        "chi_i+1_j+1",  # Q8
        "chi_0_0",      # H27 / M27
    }


def _block_expectations(group, blocks: dict[str, np.ndarray]):
    # Energy diagnostics center over the group dimension, removing the trivial
    # one-dimensional subspace. Under isotropic random features, expected energy
    # in a nontrivial block is rank(P)/( |G|-1 ).
    denom = max(group.order - 1, 1)
    out = {}
    for name, p in blocks.items():
        rank = float(np.trace(p).real)
        out[name] = 0.0 if _is_trivial_block(group.name, name) else rank / denom
    return out


def _trajectory_rows(group, model, blocks, step: int):
    left, right, unembed = model.effective_tables()
    expected = _block_expectations(group, blocks)
    rows = []
    summary_rows = []
    for table_name, table in (("left", left), ("right", right), ("unembed", unembed)):
        energy = embedding_isotypic_energy(table.detach(), blocks, center=True)
        names = list(blocks)
        for name in names:
            vals = energy[name]
            for m, val in enumerate(vals.tolist()):
                rows.append({
                    "group": group.name,
                    "model": m,
                    "step": step,
                    "table": table_name,
                    "block": name,
                    "energy": float(val),
                    "isotropic_expected_energy": float(expected[name]),
                })

        mat = torch.stack([energy[n] for n in names], dim=1).float()
        exp = torch.tensor([expected[n] for n in names], dtype=mat.dtype).unsqueeze(0)
        # Numerical normalization protects entropy from tiny partition error.
        probs = mat / mat.sum(dim=1, keepdim=True).clamp_min(1e-12)
        structure_score = 0.5 * (mat - exp).abs().sum(dim=1)
        entropy = -(probs.clamp_min(1e-12) * probs.clamp_min(1e-12).log()).sum(dim=1)
        effective_blocks = entropy.exp()
        dominance = probs.max(dim=1).values
        for m in range(model.num_models):
            summary_rows.append({
                "group": group.name,
                "model": m,
                "step": step,
                "table": table_name,
                "structure_score": float(structure_score[m]),
                "block_entropy": float(entropy[m]),
                "effective_blocks": float(effective_blocks[m]),
                "dominant_block_energy": float(dominance[m]),
            })
    return rows, summary_rows



def _causal_trajectory_rows(group, model, x, y, labels, train_mask, test_mask, blocks, quotient_labels, step: int):
    """Measure causal importance of each real-stable representation block.

    We ablate a block from both effective input pathways while leaving the
    unembedding fixed. Recording train and held-out effects separately lets us
    distinguish circuits that support memorization from circuits that support
    generalization.
    """
    left, right, _ = model.effective_tables()
    rows = []
    with torch.no_grad():
        base_logits = model(x, y)
        base_train_loss = per_model_losses(base_logits, labels, train_mask)
        base_test_loss = per_model_losses(base_logits, labels, test_mask)
        base_train_acc = per_model_accuracy(base_logits, labels, train_mask)
        base_test_acc = per_model_accuracy(base_logits, labels, test_mask)
        base_train_qacc = per_model_quotient_accuracy(base_logits, labels, train_mask, quotient_labels)
        base_test_qacc = per_model_quotient_accuracy(base_logits, labels, test_mask, quotient_labels)
        for name, proj in blocks.items():
            if _is_trivial_block(group.name, name):
                continue
            left_ab = ablate_group_component(left.detach(), proj)
            right_ab = ablate_group_component(right.detach(), proj)
            logits_ab = model(x, y, effective_override=(left_ab, right_ab))
            tr_loss_ab = per_model_losses(logits_ab, labels, train_mask)
            te_loss_ab = per_model_losses(logits_ab, labels, test_mask)
            tr_acc_ab = per_model_accuracy(logits_ab, labels, train_mask)
            te_acc_ab = per_model_accuracy(logits_ab, labels, test_mask)
            tr_qacc_ab = per_model_quotient_accuracy(logits_ab, labels, train_mask, quotient_labels)
            te_qacc_ab = per_model_quotient_accuracy(logits_ab, labels, test_mask, quotient_labels)
            for m in range(model.num_models):
                rows.append({
                    "group": group.name,
                    "model": m,
                    "step": int(step),
                    "component": name,
                    "train_loss_delta": float(tr_loss_ab[m] - base_train_loss[m]),
                    "test_loss_delta": float(te_loss_ab[m] - base_test_loss[m]),
                    "train_acc_delta": float(tr_acc_ab[m] - base_train_acc[m]),
                    "test_acc_delta": float(te_acc_ab[m] - base_test_acc[m]),
                    "base_train_acc": float(base_train_acc[m]),
                    "base_test_acc": float(base_test_acc[m]),
                    "base_train_quotient_acc": float(base_train_qacc[m]),
                    "base_test_quotient_acc": float(base_test_qacc[m]),
                    "train_quotient_acc_delta": float(tr_qacc_ab[m] - base_train_qacc[m]),
                    "test_quotient_acc_delta": float(te_qacc_ab[m] - base_test_qacc[m]),
                })
    return rows

def train_phase_minus_one(
    group_name: str,
    num_models: int = 16,
    train_fraction: float = 0.4,
    d_embed: int = 256,
    d_hidden: int = 128,
    steps: int = 250_000,
    lr: float = 1e-3,
    weight_decay: float = 1.0,
    beta1: float = 0.9,
    beta2: float = 0.98,
    seed_base: int = 0,
    same_split: bool = True,
    device: str = "cpu",
    log_every: int = 1000,
    structure_every: int | None = None,
    out_dir: str | Path = "results",
    resume_checkpoint: str | Path | None = None,
    progress_every: int = 0,
    causal_every: int = 0,
):
    group = make_group(group_name)
    x, y, labels = composition_dataset(group, device=device)
    p = labels.numel()
    init_seeds = [seed_base + i for i in range(num_models)]
    split_seeds = (
        [seed_base + 100_000] * num_models
        if same_split
        else [seed_base + 100_000 + i for i in range(num_models)]
    )
    train_mask = make_split_masks(num_models, p, train_fraction, split_seeds, device=device)
    test_mask = ~train_mask
    quotient_labels = torch.tensor(group.center_quotient_labels(), device=device, dtype=torch.long)

    model = EnsembleGroupMLP(num_models, group.order, d_embed, d_hidden, init_seeds, device=device)
    opt = torch.optim.AdamW(
        model.parameters(), lr=lr, weight_decay=weight_decay, betas=(beta1, beta2)
    )
    blocks = real_isotypic_blocks(group)
    rows = []
    structure_rows = []
    structure_summary_rows = []
    causal_rows = []
    structure_every = log_every if structure_every is None else structure_every
    start_step = 0
    resumed_from = None
    prior_checkpoint_states = {}

    if resume_checkpoint is not None:
        resume_checkpoint = Path(resume_checkpoint)
        payload = torch.load(resume_checkpoint, map_location=device, weights_only=False)
        prior = payload["config"]
        expected = {
            "group": group.name, "num_models": num_models, "train_fraction": train_fraction,
            "d_embed": d_embed, "d_hidden": d_hidden, "lr": lr,
            "weight_decay": weight_decay, "betas": [beta1, beta2],
            "seed_base": seed_base, "same_split": same_split,
        }
        for key, val in expected.items():
            if key in prior and prior[key] != val:
                raise ValueError(f"Resume mismatch for {key}: checkpoint={prior[key]!r}, requested={val!r}")
        model.load_state_dict(payload["model_state"])
        if "optimizer_state" not in payload:
            raise ValueError("Checkpoint has no optimizer_state; use a checkpoint produced by the resumable runner")
        opt.load_state_dict(payload["optimizer_state"])
        start_step = int(payload.get("current_step", prior.get("steps", 0)))
        if steps <= start_step:
            raise ValueError(f"Target steps ({steps}) must exceed checkpoint step ({start_step})")
        resumed_from = str(resume_checkpoint)
        prior_checkpoint_states = payload.get("checkpoints", {})

        if resume_checkpoint.name.endswith("_checkpoints.pt"):
            stem_old = resume_checkpoint.name.removesuffix("_checkpoints.pt")
        elif resume_checkpoint.name.endswith("_progress.pt"):
            stem_old = resume_checkpoint.name.removesuffix("_progress.pt")
        else:
            raise ValueError("Resume file must end in _checkpoints.pt or _progress.pt")
        parent = resume_checkpoint.parent
        old_metrics = parent / f"{stem_old}_metrics.csv"
        old_structure = parent / f"{stem_old}_structure.csv"
        old_structure_summary = parent / f"{stem_old}_structure_summary.csv"
        old_causal = parent / f"{stem_old}_causal_trajectory.csv"
        if old_metrics.exists():
            rows.extend(pd.read_csv(old_metrics).to_dict("records"))
        if old_structure.exists():
            structure_rows.extend(pd.read_csv(old_structure).to_dict("records"))
        if old_structure_summary.exists():
            structure_summary_rows.extend(pd.read_csv(old_structure_summary).to_dict("records"))
        if old_causal.exists():
            causal_rows.extend(pd.read_csv(old_causal).to_dict("records"))

    checkpoint_steps = {0, steps}
    for frac in (0.01, 0.05, 0.10, 0.25, 0.50):
        checkpoint_steps.add(max(1, round(frac * steps)))
    checkpoint_states = dict(prior_checkpoint_states)

    def snapshot():
        left, right, unembed = model.effective_tables()
        return {
            "effective_left": left.detach().cpu().clone(),
            "effective_right": right.detach().cpu().clone(),
            "unembedding": unembed.detach().cpu().clone(),
        }

    def record_metrics(step: int):
        with torch.no_grad():
            logits = model(x, y)
            tr_loss = per_model_losses(logits, labels, train_mask)
            te_loss = per_model_losses(logits, labels, test_mask)
            tr_acc = per_model_accuracy(logits, labels, train_mask)
            te_acc = per_model_accuracy(logits, labels, test_mask)
            tr_qacc = per_model_quotient_accuracy(logits, labels, train_mask, quotient_labels)
            te_qacc = per_model_quotient_accuracy(logits, labels, test_mask, quotient_labels)
            tr_fiber = per_model_exact_given_quotient(logits, labels, train_mask, quotient_labels)
            te_fiber = per_model_exact_given_quotient(logits, labels, test_mask, quotient_labels)
            sqnorm = model.per_model_sqnorm()
        for m in range(num_models):
            rows.append({
                "group": group.name,
                "model": m,
                "step": step,
                "init_seed": init_seeds[m],
                "split_seed": split_seeds[m],
                "train_fraction": train_fraction,
                "d_embed": d_embed,
                "d_hidden": d_hidden,
                "lr": lr,
                "weight_decay": weight_decay,
                "beta1": beta1,
                "beta2": beta2,
                "train_loss": float(tr_loss[m]),
                "test_loss": float(te_loss[m]),
                "train_acc": float(tr_acc[m]),
                "test_acc": float(te_acc[m]),
                "train_quotient_acc": float(tr_qacc[m]),
                "test_quotient_acc": float(te_qacc[m]),
                "train_exact_given_quotient": float(tr_fiber[m]),
                "test_exact_given_quotient": float(te_fiber[m]),
                "parameter_sqnorm": float(sqnorm[m]),
            })

    def record_structure(step: int):
        with torch.no_grad():
            detail, summary = _trajectory_rows(group, model, blocks, step)
        structure_rows.extend(detail)
        structure_summary_rows.extend(summary)

    if start_step == 0:
        record_metrics(0)
        record_structure(0)
        checkpoint_states[0] = snapshot()

    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    stem = f"{group.name.lower()}_n{num_models}_f{train_fraction:.2f}_s{steps}_seed{seed_base}"
    metrics_path = out_dir / f"{stem}_metrics.csv"
    mech_path = out_dir / f"{stem}_mechanism.csv"
    structure_path = out_dir / f"{stem}_structure.csv"
    structure_summary_path = out_dir / f"{stem}_structure_summary.csv"
    causal_path = out_dir / f"{stem}_causal_trajectory.csv"
    ckpt_path = out_dir / f"{stem}_checkpoints.pt"
    progress_path = out_dir / f"{stem}_progress.pt"

    def persist_progress(step: int):
        pd.DataFrame(rows).to_csv(metrics_path, index=False)
        pd.DataFrame(structure_rows).to_csv(structure_path, index=False)
        pd.DataFrame(structure_summary_rows).to_csv(structure_summary_path, index=False)
        if causal_rows:
            pd.DataFrame(causal_rows).to_csv(causal_path, index=False)
        torch.save({
            "config": {
                "group": group.name, "num_models": num_models, "train_fraction": train_fraction,
                "d_embed": d_embed, "d_hidden": d_hidden, "steps": steps,
                "lr": lr, "weight_decay": weight_decay, "betas": [beta1, beta2],
                "seed_base": seed_base, "same_split": same_split,
                "log_every": log_every, "structure_every": structure_every,
                "causal_every": causal_every,
            },
            "current_step": step,
            "resumed_from": resumed_from,
            "init_seeds": init_seeds,
            "split_seeds": split_seeds,
            "checkpoints": checkpoint_states,
            "model_state": model.state_dict(),
            "optimizer_state": opt.state_dict(),
        }, progress_path)

    for step in range(start_step + 1, steps + 1):
        opt.zero_grad(set_to_none=True)
        logits = model(x, y)
        losses = per_model_losses(logits, labels, train_mask)
        # The ensemble axis indexes disjoint parameter blocks. Summing gives each
        # member exactly its standalone gradient, unlike mean() which rescales it.
        losses.sum().backward()
        opt.step()

        if step % log_every == 0 or step == steps:
            record_metrics(step)
        if step % structure_every == 0 or step == steps:
            record_structure(step)
        if causal_every > 0 and (step % causal_every == 0 or step == steps):
            causal_rows.extend(_causal_trajectory_rows(
                group, model, x, y, labels, train_mask, test_mask, blocks, quotient_labels, step
            ))
        if step in checkpoint_steps:
            checkpoint_states[step] = snapshot()
        if progress_every > 0 and step % progress_every == 0 and step != steps:
            persist_progress(step)

    left, right, unembed = model.effective_tables()
    mech_rows = []
    for table_name, table in (("left", left), ("right", right), ("unembed", unembed)):
        energy = embedding_isotypic_energy(table.detach(), blocks)
        for name, vals in energy.items():
            for m, val in enumerate(vals.tolist()):
                mech_rows.append({
                    "group": group.name,
                    "model": m,
                    "table": table_name,
                    "component": name,
                    "isotypic_energy": val,
                })

    # Phase -1 causal viability: remove each real-stable block from both effective
    # input pathways and measure held-out degradation.
    with torch.no_grad():
        base_logits = model(x, y)
        base_test_loss = per_model_losses(base_logits, labels, test_mask)
        base_test_acc = per_model_accuracy(base_logits, labels, test_mask)
        for name, proj in blocks.items():
            if _is_trivial_block(group.name, name):
                continue
            left_ab = ablate_group_component(left.detach(), proj)
            right_ab = ablate_group_component(right.detach(), proj)
            logits_ab = model(x, y, effective_override=(left_ab, right_ab))
            loss_ab = per_model_losses(logits_ab, labels, test_mask)
            acc_ab = per_model_accuracy(logits_ab, labels, test_mask)
            for m in range(num_models):
                mech_rows.append({
                    "group": group.name,
                    "model": m,
                    "table": "left+right",
                    "component": name,
                    "ablation_test_loss_delta": float(loss_ab[m] - base_test_loss[m]),
                    "ablation_test_acc_delta": float(acc_ab[m] - base_test_acc[m]),
                })

    pd.DataFrame(rows).to_csv(metrics_path, index=False)
    pd.DataFrame(mech_rows).to_csv(mech_path, index=False)
    pd.DataFrame(structure_rows).to_csv(structure_path, index=False)
    pd.DataFrame(structure_summary_rows).to_csv(structure_summary_path, index=False)
    if causal_rows:
        pd.DataFrame(causal_rows).to_csv(causal_path, index=False)
    torch.save(
        {
            "config": {
                "group": group.name,
                "num_models": num_models,
                "train_fraction": train_fraction,
                "d_embed": d_embed,
                "d_hidden": d_hidden,
                "steps": steps,
                "lr": lr,
                "weight_decay": weight_decay,
                "betas": [beta1, beta2],
                "seed_base": seed_base,
                "same_split": same_split,
                "log_every": log_every,
                "structure_every": structure_every,
                "causal_every": causal_every,
            },
            "current_step": steps,
            "resumed_from": resumed_from,
            "init_seeds": init_seeds,
            "split_seeds": split_seeds,
            "checkpoints": checkpoint_states,
            "model_state": model.state_dict(),
            "optimizer_state": opt.state_dict(),
        },
        ckpt_path,
    )
    return metrics_path, mech_path, structure_path, structure_summary_path, causal_path, ckpt_path


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--group", default="H27", choices=["D8", "Q8", "H27", "M27"])
    ap.add_argument("--num-models", type=int, default=16)
    ap.add_argument("--train-fraction", type=float, default=0.4)
    ap.add_argument("--d-embed", type=int, default=256)
    ap.add_argument("--d-hidden", type=int, default=128)
    ap.add_argument("--steps", type=int, default=250000)
    ap.add_argument("--lr", type=float, default=1e-3)
    ap.add_argument("--weight-decay", type=float, default=1.0)
    ap.add_argument("--beta1", type=float, default=0.9)
    ap.add_argument("--beta2", type=float, default=0.98)
    ap.add_argument("--seed-base", type=int, default=0)
    ap.add_argument("--different-splits", action="store_true")
    ap.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    ap.add_argument("--log-every", type=int, default=1000)
    ap.add_argument("--structure-every", type=int)
    ap.add_argument("--out-dir", default="results")
    ap.add_argument("--resume")
    ap.add_argument("--progress-every", type=int, default=0)
    ap.add_argument("--causal-every", type=int, default=0)
    args = ap.parse_args()

    if args.resume:
        payload = torch.load(args.resume, map_location="cpu", weights_only=False)
        cfg = payload["config"]
        args.group = cfg["group"]
        args.num_models = cfg["num_models"]
        args.train_fraction = cfg["train_fraction"]
        args.d_embed = cfg["d_embed"]
        args.d_hidden = cfg["d_hidden"]
        args.lr = cfg["lr"]
        args.weight_decay = cfg["weight_decay"]
        args.beta1, args.beta2 = cfg["betas"]
        args.seed_base = cfg["seed_base"]
        args.different_splits = not cfg["same_split"]
    paths = train_phase_minus_one(
        group_name=args.group,
        num_models=args.num_models,
        train_fraction=args.train_fraction,
        d_embed=args.d_embed,
        d_hidden=args.d_hidden,
        steps=args.steps,
        lr=args.lr,
        weight_decay=args.weight_decay,
        beta1=args.beta1,
        beta2=args.beta2,
        seed_base=args.seed_base,
        same_split=not args.different_splits,
        device=args.device,
        log_every=args.log_every,
        structure_every=args.structure_every,
        out_dir=args.out_dir,
        resume_checkpoint=args.resume,
        progress_every=args.progress_every,
        causal_every=args.causal_every,
    )
    print(json.dumps([str(p) for p in paths], indent=2))


if __name__ == "__main__":
    main()
