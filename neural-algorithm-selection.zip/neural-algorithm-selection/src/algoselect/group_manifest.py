from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np

from .groups import make_group
from .representations import characters, frobenius_schur_indicators, real_isotypic_blocks


def describe_group(name: str):
    g = make_group(name)
    chars = characters(g)
    fs = frobenius_schur_indicators(g)
    blocks = real_isotypic_blocks(g)
    return {
        "name": g.name,
        "order": g.order,
        "exponent": max(g.element_order(x) for x in g.elements),
        "num_involutive_solutions_g2_eq_e": sum(g.mul(x, x) == g.identity for x in g.elements),
        "irreps": [
            {
                "name": irrep,
                "complex_dimension": int(dim),
                "frobenius_schur_indicator": int(fs[irrep]) if isinstance(fs[irrep], int) else str(fs[irrep]),
            }
            for irrep, (dim, _) in chars.items()
        ],
        "real_stable_blocks": [
            {"name": block, "regular_representation_rank": int(round(np.trace(p).real))}
            for block, p in blocks.items()
        ],
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--out', default='results/group_manifest.json')
    args = ap.parse_args()
    payload = {name: describe_group(name) for name in ('D8', 'Q8', 'H27', 'M27')}
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(payload, indent=2))
    print(json.dumps(payload, indent=2))


if __name__ == '__main__':
    main()
