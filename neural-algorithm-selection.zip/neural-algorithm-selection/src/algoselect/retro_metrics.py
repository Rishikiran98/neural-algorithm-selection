from __future__ import annotations

import argparse
from pathlib import Path

import pandas as pd
import torch
import torch.nn.functional as F

from .data import composition_dataset, make_split_masks
from .groups import make_group
from .model import (
    per_model_accuracy,
    per_model_exact_given_quotient,
    per_model_losses,
    per_model_quotient_accuracy,
)


def _logits(snapshot, x, y):
    left = snapshot['effective_left'].to(x.device)
    right = snapshot['effective_right'].to(x.device)
    unembed = snapshot['unembedding'].to(x.device)
    h = F.relu(left[:, x, :] + right[:, y, :])
    return torch.einsum('mbh,moh->mbo', h, unembed)


def retroactive_metrics(checkpoint_path: str | Path, device: str = 'cpu') -> pd.DataFrame:
    payload = torch.load(checkpoint_path, map_location='cpu', weights_only=False)
    cfg = payload['config']
    group = make_group(cfg['group'])
    x, y, labels = composition_dataset(group, device=device)
    n = int(cfg['num_models'])
    seed_base = int(cfg['seed_base'])
    split_seeds = (
        [seed_base + 100_000] * n
        if cfg['same_split'] else [seed_base + 100_000 + i for i in range(n)]
    )
    train_mask = make_split_masks(
        n, labels.numel(), float(cfg['train_fraction']), split_seeds, device=device
    )
    test_mask = ~train_mask
    qlabels = torch.tensor(group.center_quotient_labels(), dtype=torch.long, device=device)
    rows = []
    for step_raw, snap in sorted(payload.get('checkpoints', {}).items(), key=lambda kv: int(kv[0])):
        step = int(step_raw)
        with torch.no_grad():
            logits = _logits(snap, x, y)
            tr_loss = per_model_losses(logits, labels, train_mask)
            te_loss = per_model_losses(logits, labels, test_mask)
            tr_acc = per_model_accuracy(logits, labels, train_mask)
            te_acc = per_model_accuracy(logits, labels, test_mask)
            tr_q = per_model_quotient_accuracy(logits, labels, train_mask, qlabels)
            te_q = per_model_quotient_accuracy(logits, labels, test_mask, qlabels)
            tr_f = per_model_exact_given_quotient(logits, labels, train_mask, qlabels)
            te_f = per_model_exact_given_quotient(logits, labels, test_mask, qlabels)
        for m in range(n):
            rows.append({
                'group': group.name,
                'model': m,
                'step': step,
                'train_loss': float(tr_loss[m]),
                'test_loss': float(te_loss[m]),
                'train_acc': float(tr_acc[m]),
                'test_acc': float(te_acc[m]),
                'train_quotient_acc': float(tr_q[m]),
                'test_quotient_acc': float(te_q[m]),
                'train_exact_given_quotient': float(tr_f[m]),
                'test_exact_given_quotient': float(te_f[m]),
            })
    return pd.DataFrame(rows)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('checkpoint')
    ap.add_argument('--out', required=True)
    ap.add_argument('--device', default='cpu')
    args = ap.parse_args()
    df = retroactive_metrics(args.checkpoint, args.device)
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(out, index=False)
    print(out)


if __name__ == '__main__':
    main()
