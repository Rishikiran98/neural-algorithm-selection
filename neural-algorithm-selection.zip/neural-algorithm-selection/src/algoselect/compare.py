from __future__ import annotations

import argparse
from pathlib import Path

import pandas as pd

from .analyze import mechanism_fingerprints, seed_divergence, fingerprint_drift
from .screen import summarize_metrics, summarize_structure


def _single(directory: Path, pattern: str) -> Path:
    hits = sorted(directory.glob(pattern))
    if len(hits) != 1:
        raise ValueError(f'{directory}: expected exactly one {pattern}, found {len(hits)}')
    return hits[0]


def summarize_directory(directory: str | Path) -> dict:
    d = Path(directory)
    metrics = _single(d, '*_metrics.csv')
    structure_summary = _single(d, '*_structure_summary.csv')
    structure = _single(d, '*_structure.csv')
    mper, ms = summarize_metrics(metrics)
    sper, ss = summarize_structure(structure_summary)
    raw = pd.read_csv(metrics)
    cfg = raw.iloc[0]
    fp = mechanism_fingerprints(structure)
    div = seed_divergence(fp)
    drift = fingerprint_drift(fp)
    mean_pair = div[div.record_type == 'mean_pairwise']
    final_step = int(raw.step.max())
    final = raw[raw.step == final_step]
    out = {
        'run_dir': str(d),
        'group': str(cfg.group),
        'train_fraction': float(cfg.train_fraction),
        'n_models': int(ms['n_models']),
        'final_step': final_step,
        'memorized_fraction': ms['memorized_fraction'],
        'median_t_mem': ms['median_t_mem'],
        'median_t_test_loss_peak': ms['median_t_test_loss_peak'],
        'median_cleanup_loss_drop': ms['median_cleanup_loss_drop'],
        'final_mean_test_acc': float(final.test_acc.mean()),
        'final_median_test_acc': float(final.test_acc.median()),
        'final_mean_test_loss': float(final.test_loss.mean()),
        'structured_fraction': ss['structured_fraction'],
        'median_t_structure': ss['median_t_structure'],
        'final_mean_pairwise_seed_js': None if mean_pair.empty else float(mean_pair.sort_values('step').iloc[-1].js_divergence),
        'max_mean_pairwise_seed_js': None if mean_pair.empty else float(mean_pair.js_divergence.max()),
        'final_mean_js_from_init': float(drift[drift.step == drift.step.max()].js_from_init.mean()),
    }
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--run', action='append', required=True, help='result directory containing one completed run')
    ap.add_argument('--out', required=True)
    args = ap.parse_args()
    df = pd.DataFrame([summarize_directory(x) for x in args.run])
    df.to_csv(args.out, index=False)
    print(df.to_string(index=False))


if __name__ == '__main__':
    main()
