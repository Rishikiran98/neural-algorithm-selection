from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd


def first_crossing(g: pd.DataFrame, column: str, threshold: float):
    hit = g[g[column] >= threshold]
    return None if hit.empty else int(hit.iloc[0].step)


def _first_persistent_crossing(steps, values, threshold: float, persistence: int = 2):
    steps = np.asarray(steps)
    values = np.asarray(values)
    above = values >= threshold
    if persistence <= 1:
        idx = np.flatnonzero(above)
        return None if len(idx) == 0 else int(steps[idx[0]])
    for i in range(0, len(above) - persistence + 1):
        if above[i : i + persistence].all():
            return int(steps[i])
    return None


def summarize_metrics(path: str | Path, memorize_threshold=0.99, generalize_threshold=0.90):
    df = pd.read_csv(path)
    final_step = int(df.step.max())
    rows = []
    for model, g in df.sort_values("step").groupby("model"):
        final = g[g.step == final_step].iloc[-1]
        t_mem = first_crossing(g, "train_acc", memorize_threshold)
        t_gen = first_crossing(g, "test_acc", generalize_threshold)
        post_mem = g[g.step >= t_mem] if t_mem is not None else g
        peak_idx = post_mem.test_loss.idxmax()
        peak_row = post_mem.loc[peak_idx]
        t_test_loss_peak = int(peak_row.step)
        peak_test_loss = float(peak_row.test_loss)
        cleanup_drop = peak_test_loss - float(final.test_loss)
        rows.append(
            {
                "model": int(model),
                "t_mem": t_mem,
                "t_test_loss_peak": t_test_loss_peak,
                "peak_test_loss": peak_test_loss,
                "cleanup_loss_drop": cleanup_drop,
                "t_gen": t_gen,
                "grok_delay": None if t_mem is None or t_gen is None else t_gen - t_mem,
                "final_train_acc": float(final.train_acc),
                "final_test_acc": float(final.test_acc),
                "final_train_loss": float(final.train_loss),
                "final_test_loss": float(final.test_loss),
                "generalized": t_gen is not None,
            }
        )
    per_model = pd.DataFrame(rows)
    summary = {
        "metrics_file": str(path),
        "n_models": len(per_model),
        "final_step": final_step,
        "memorized_fraction": float(per_model.t_mem.notna().mean()),
        "generalized_fraction": float(per_model.generalized.mean()),
        "median_final_test_acc": float(per_model.final_test_acc.median()),
        "mean_final_test_acc": float(per_model.final_test_acc.mean()),
        "median_t_mem": None
        if per_model.t_mem.dropna().empty
        else float(per_model.t_mem.dropna().median()),
        "median_t_test_loss_peak": None
        if per_model.t_test_loss_peak.dropna().empty
        else float(per_model.t_test_loss_peak.dropna().median()),
        "median_cleanup_loss_drop": float(per_model.cleanup_loss_drop.median()),
        "cleanup_fraction": float((per_model.cleanup_loss_drop > 0.5).mean()),
        "median_t_gen": None
        if per_model.t_gen.dropna().empty
        else float(per_model.t_gen.dropna().median()),
        "viability_accuracy_gate": bool(per_model.generalized.mean() >= 0.25),
    }
    return per_model, summary


def summarize_structure(
    path: str | Path,
    min_delta: float = 0.05,
    robust_z: float = 5.0,
    persistence: int = 2,
    onset_fraction_gate: float = 0.25,
):
    """Detect onset of representation concentration relative to random initialization.

    The input is the structure_summary CSV emitted during training. For each model
    and step we use the maximum structure score across left/right/unembedding.
    The onset threshold is ensemble-calibrated from t=0 using median + max(min_delta,
    robust_z * MAD-scale). This deliberately favors specificity over sensitivity.
    """
    df = pd.read_csv(path)
    required = {"model", "step", "table", "structure_score"}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"structure summary missing columns: {sorted(missing)}")

    mx = (
        df.groupby(["model", "step"], as_index=False)
        .structure_score.max()
        .rename(columns={"structure_score": "max_structure_score"})
        .sort_values(["model", "step"])
    )
    baseline = mx[mx.step == mx.step.min()].max_structure_score.to_numpy()
    med = float(np.median(baseline))
    mad = float(np.median(np.abs(baseline - med)))
    robust_sigma = 1.4826 * mad
    threshold = med + max(float(min_delta), float(robust_z) * robust_sigma)

    rows = []
    for model, g in mx.groupby("model"):
        g = g.sort_values("step")
        t_structure = _first_persistent_crossing(
            g.step.to_numpy(), g.max_structure_score.to_numpy(), threshold, persistence
        )
        final = g.iloc[-1]
        rows.append(
            {
                "model": int(model),
                "t_structure": t_structure,
                "final_max_structure_score": float(final.max_structure_score),
                "structured": t_structure is not None,
            }
        )
    per_model = pd.DataFrame(rows)
    structured_fraction = float(per_model.structured.mean())
    summary = {
        "structure_file": str(path),
        "structure_baseline_median": med,
        "structure_baseline_robust_sigma": robust_sigma,
        "structure_threshold": threshold,
        "structured_fraction": structured_fraction,
        "median_t_structure": None
        if per_model.t_structure.dropna().empty
        else float(per_model.t_structure.dropna().median()),
        "structure_gate": bool(structured_fraction >= onset_fraction_gate),
    }
    return per_model, summary


def mechanism_gate(path: str | Path, min_loss_delta=0.25):
    df = pd.read_csv(path)
    ab = (
        df[df.ablation_test_loss_delta.notna()].copy()
        if "ablation_test_loss_delta" in df
        else pd.DataFrame()
    )
    if ab.empty:
        return {
            "mechanism_file": str(path),
            "causal_gate": False,
            "max_mean_ablation_loss_delta": None,
        }
    grouped = (
        ab.groupby("component").ablation_test_loss_delta.mean().sort_values(ascending=False)
    )
    best = float(grouped.iloc[0])
    return {
        "mechanism_file": str(path),
        "causal_gate": bool(best >= min_loss_delta),
        "max_mean_ablation_loss_delta": best,
        "best_component": str(grouped.index[0]),
    }


def combine_timelines(metric_per_model: pd.DataFrame, structure_per_model: pd.DataFrame | None):
    out = metric_per_model.copy()
    if structure_per_model is not None:
        out = out.merge(structure_per_model, on="model", how="left")
        out["structure_after_mem"] = np.where(
            out.t_structure.notna() & out.t_mem.notna(), out.t_structure - out.t_mem, np.nan
        )
        out["generalization_after_structure"] = np.where(
            out.t_gen.notna() & out.t_structure.notna(), out.t_gen - out.t_structure, np.nan
        )
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("metrics")
    ap.add_argument("--mechanism")
    ap.add_argument("--structure-summary")
    ap.add_argument("--out")
    ap.add_argument("--structure-min-delta", type=float, default=0.05)
    ap.add_argument("--structure-robust-z", type=float, default=5.0)
    ap.add_argument("--structure-persistence", type=int, default=2)
    args = ap.parse_args()

    per, summary = summarize_metrics(args.metrics)
    structure_per = None
    if args.structure_summary:
        structure_per, structure_summary = summarize_structure(
            args.structure_summary,
            min_delta=args.structure_min_delta,
            robust_z=args.structure_robust_z,
            persistence=args.structure_persistence,
        )
        summary.update(structure_summary)
    if args.mechanism:
        summary.update(mechanism_gate(args.mechanism))

    summary["phase_minus_one_pass"] = bool(
        summary.get("viability_accuracy_gate", False)
        and summary.get("structure_gate", False)
        and summary.get("causal_gate", False)
    )
    print(pd.Series(summary).to_string())
    if args.out:
        out = Path(args.out)
        out.parent.mkdir(parents=True, exist_ok=True)
        combine_timelines(per, structure_per).to_csv(out, index=False)


if __name__ == "__main__":
    main()
