from __future__ import annotations

import torch
from .groups import FiniteGroup


def composition_dataset(group: FiniteGroup, device: str | torch.device = "cpu"):
    n = group.order
    xs, ys, labels = [], [], []
    for i, a in enumerate(group.elements):
        for j, b in enumerate(group.elements):
            xs.append(i)
            ys.append(j)
            labels.append(group.index[group.mul(a, b)])
    return (
        torch.tensor(xs, dtype=torch.long, device=device),
        torch.tensor(ys, dtype=torch.long, device=device),
        torch.tensor(labels, dtype=torch.long, device=device),
    )


def make_split_masks(num_models: int, num_examples: int, train_fraction: float, seeds: list[int], device="cpu"):
    if len(seeds) != num_models:
        raise ValueError("one data seed required per model")
    n_train = max(1, min(num_examples - 1, round(train_fraction * num_examples)))
    masks = torch.zeros((num_models, num_examples), dtype=torch.bool, device=device)
    for m, seed in enumerate(seeds):
        g = torch.Generator(device="cpu").manual_seed(int(seed))
        perm = torch.randperm(num_examples, generator=g)[:n_train]
        masks[m, perm.to(device)] = True
    return masks
