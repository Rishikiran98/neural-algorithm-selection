from __future__ import annotations

import math
import torch
from torch import nn
import torch.nn.functional as F


class EnsembleGroupMLP(nn.Module):
    """Tensorized version of the Chughtai-Chan-Nanda one-hidden-layer group MLP.

    For each model m:
        a -> E_left[a]
        b -> E_right[b]
        h = ReLU(E_left[a] W_left + E_right[b] W_right)
        logits = h W_U

    There are no biases and the left/right embeddings are untied, matching the
    mainline architecture in Appendix C.1 of the reference paper.
    """

    def __init__(self, num_models: int, group_order: int, d_embed: int, d_hidden: int, init_seeds: list[int], device="cpu", dtype=torch.float32):
        super().__init__()
        if len(init_seeds) != num_models:
            raise ValueError("one init seed required per model")
        self.num_models = num_models
        self.group_order = group_order
        self.d_embed = d_embed
        self.d_hidden = d_hidden
        self.left_embedding = nn.Parameter(torch.empty(num_models, group_order, d_embed, device=device, dtype=dtype))
        self.right_embedding = nn.Parameter(torch.empty(num_models, group_order, d_embed, device=device, dtype=dtype))
        self.w_left = nn.Parameter(torch.empty(num_models, d_embed, d_hidden, device=device, dtype=dtype))
        self.w_right = nn.Parameter(torch.empty(num_models, d_embed, d_hidden, device=device, dtype=dtype))
        self.w_u = nn.Parameter(torch.empty(num_models, d_hidden, group_order, device=device, dtype=dtype))
        self.reset_parameters(init_seeds)

    @torch.no_grad()
    def reset_parameters(self, seeds: list[int]):
        for m, seed in enumerate(seeds):
            g = torch.Generator(device="cpu").manual_seed(int(seed))
            # Scale each factor by fan-in. This keeps the tensorized models independent.
            le = torch.randn(self.group_order, self.d_embed, generator=g) / math.sqrt(self.group_order)
            re = torch.randn(self.group_order, self.d_embed, generator=g) / math.sqrt(self.group_order)
            wl = torch.randn(self.d_embed, self.d_hidden, generator=g) / math.sqrt(self.d_embed)
            wr = torch.randn(self.d_embed, self.d_hidden, generator=g) / math.sqrt(self.d_embed)
            wu = torch.randn(self.d_hidden, self.group_order, generator=g) / math.sqrt(self.d_hidden)
            self.left_embedding[m].copy_(le.to(self.left_embedding.device, self.left_embedding.dtype))
            self.right_embedding[m].copy_(re.to(self.right_embedding.device, self.right_embedding.dtype))
            self.w_left[m].copy_(wl.to(self.w_left.device, self.w_left.dtype))
            self.w_right[m].copy_(wr.to(self.w_right.device, self.w_right.dtype))
            self.w_u[m].copy_(wu.to(self.w_u.device, self.w_u.dtype))

    def effective_tables(self):
        left = torch.einsum("mnd,mdh->mnh", self.left_embedding, self.w_left)
        right = torch.einsum("mnd,mdh->mnh", self.right_embedding, self.w_right)
        unembed = self.w_u.transpose(1, 2)  # [M, |G|, h]
        return left, right, unembed

    def per_model_sqnorm(self):
        total = torch.zeros(self.num_models, device=self.left_embedding.device, dtype=self.left_embedding.dtype)
        for p in self.parameters():
            total = total + (p ** 2).reshape(self.num_models, -1).sum(dim=1)
        return total

    def forward(self, x: torch.Tensor, y: torch.Tensor, effective_override: tuple[torch.Tensor, torch.Tensor] | None = None):
        if effective_override is None:
            left, right, _ = self.effective_tables()
        else:
            left, right = effective_override
        h = F.relu(left[:, x, :] + right[:, y, :])
        return torch.einsum("mbh,mho->mbo", h, self.w_u)


def per_model_losses(logits: torch.Tensor, labels: torch.Tensor, mask: torch.Tensor):
    m, b, c = logits.shape
    targets = labels.unsqueeze(0).expand(m, -1)
    losses = F.cross_entropy(logits.reshape(m * b, c), targets.reshape(-1), reduction="none").reshape(m, b)
    denom = mask.sum(dim=1).clamp_min(1)
    return (losses * mask).sum(dim=1) / denom


def per_model_accuracy(logits: torch.Tensor, labels: torch.Tensor, mask: torch.Tensor):
    pred = logits.argmax(dim=-1)
    targets = labels.unsqueeze(0).expand_as(pred)
    denom = mask.sum(dim=1).clamp_min(1)
    return (((pred == targets) & mask).sum(dim=1) / denom).float()


def per_model_quotient_accuracy(logits: torch.Tensor, labels: torch.Tensor, mask: torch.Tensor, quotient_labels: torch.Tensor):
    """Accuracy after projecting predicted and true outputs to a finite-group quotient."""
    pred = logits.argmax(dim=-1)
    targets = labels.unsqueeze(0).expand_as(pred)
    q = quotient_labels.to(pred.device)
    pred_q = q[pred]
    target_q = q[targets]
    denom = mask.sum(dim=1).clamp_min(1)
    return (((pred_q == target_q) & mask).sum(dim=1) / denom).float()


def per_model_exact_given_quotient(logits: torch.Tensor, labels: torch.Tensor, mask: torch.Tensor, quotient_labels: torch.Tensor):
    """Exact accuracy conditional on predicting the correct quotient coset."""
    pred = logits.argmax(dim=-1)
    targets = labels.unsqueeze(0).expand_as(pred)
    q = quotient_labels.to(pred.device)
    q_ok = (q[pred] == q[targets]) & mask
    exact = (pred == targets) & q_ok
    denom = q_ok.sum(dim=1).clamp_min(1)
    return (exact.sum(dim=1) / denom).float()
