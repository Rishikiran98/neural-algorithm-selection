from __future__ import annotations

import argparse
from pathlib import Path

import pandas as pd
import torch
import torch.nn.functional as F

from .data import composition_dataset, make_split_masks
from .groups import make_group
from .model import per_model_accuracy, per_model_losses, per_model_quotient_accuracy
from .representations import ablate_group_component, real_isotypic_blocks
from .train import _is_trivial_block


def _logits_from_snapshot(snapshot: dict[str, torch.Tensor], x: torch.Tensor, y: torch.Tensor,
                          left_override: torch.Tensor | None = None,
                          right_override: torch.Tensor | None = None) -> torch.Tensor:
    left = snapshot['effective_left'].to(x.device) if left_override is None else left_override
    right = snapshot['effective_right'].to(x.device) if right_override is None else right_override
    unembed = snapshot['unembedding'].to(x.device)  # [M, |G|, h]
    h = F.relu(left[:, x, :] + right[:, y, :])
    return torch.einsum('mbh,moh->mbo', h, unembed)


def retroactive_causal_trajectory(checkpoint_path: str | Path, device: str = 'cpu') -> pd.DataFrame:
    payload = torch.load(checkpoint_path, map_location='cpu', weights_only=False)
    cfg = payload['config']
    group = make_group(cfg['group'])
    x, y, labels = composition_dataset(group, device=device)
    num_models = int(cfg['num_models'])
    p = labels.numel()
    seed_base = int(cfg['seed_base'])
    same_split = bool(cfg['same_split'])
    split_seeds = (
        [seed_base + 100_000] * num_models
        if same_split else [seed_base + 100_000 + i for i in range(num_models)]
    )
    train_mask = make_split_masks(
        num_models, p, float(cfg['train_fraction']), split_seeds, device=device
    )
    test_mask = ~train_mask
    quotient_labels = torch.tensor(group.center_quotient_labels(), device=device, dtype=torch.long)
    blocks = real_isotypic_blocks(group)

    rows = []
    for step_raw, snapshot in sorted(payload.get('checkpoints', {}).items(), key=lambda kv: int(kv[0])):
        step = int(step_raw)
        snap = {k: v.to(device) for k, v in snapshot.items()}
        with torch.no_grad():
            base_logits = _logits_from_snapshot(snap, x, y)
            base_train_loss = per_model_losses(base_logits, labels, train_mask)
            base_test_loss = per_model_losses(base_logits, labels, test_mask)
            base_train_acc = per_model_accuracy(base_logits, labels, train_mask)
            base_test_acc = per_model_accuracy(base_logits, labels, test_mask)
            base_train_qacc = per_model_quotient_accuracy(base_logits, labels, train_mask, quotient_labels)
            base_test_qacc = per_model_quotient_accuracy(base_logits, labels, test_mask, quotient_labels)
            for name, proj in blocks.items():
                if _is_trivial_block(group.name, name):
                    continue
                left_ab = ablate_group_component(snap['effective_left'], proj)
                right_ab = ablate_group_component(snap['effective_right'], proj)
                logits_ab = _logits_from_snapshot(snap, x, y, left_ab, right_ab)
                tr_loss_ab = per_model_losses(logits_ab, labels, train_mask)
                te_loss_ab = per_model_losses(logits_ab, labels, test_mask)
                tr_acc_ab = per_model_accuracy(logits_ab, labels, train_mask)
                te_acc_ab = per_model_accuracy(logits_ab, labels, test_mask)
                tr_qacc_ab = per_model_quotient_accuracy(logits_ab, labels, train_mask, quotient_labels)
                te_qacc_ab = per_model_quotient_accuracy(logits_ab, labels, test_mask, quotient_labels)
                for m in range(num_models):
                    rows.append({
                        'group': group.name,
                        'model': m,
                        'step': step,
                        'component': name,
                        'train_loss_delta': float(tr_loss_ab[m] - base_train_loss[m]),
                        'test_loss_delta': float(te_loss_ab[m] - base_test_loss[m]),
                        'train_acc_delta': float(tr_acc_ab[m] - base_train_acc[m]),
                        'test_acc_delta': float(te_acc_ab[m] - base_test_acc[m]),
                        'base_train_acc': float(base_train_acc[m]),
                        'base_test_acc': float(base_test_acc[m]),
                        'base_train_quotient_acc': float(base_train_qacc[m]),
                        'base_test_quotient_acc': float(base_test_qacc[m]),
                        'train_quotient_acc_delta': float(tr_qacc_ab[m] - base_train_qacc[m]),
                        'test_quotient_acc_delta': float(te_qacc_ab[m] - base_test_qacc[m]),
                        'base_train_loss': float(base_train_loss[m]),
                        'base_test_loss': float(base_test_loss[m]),
                    })
    return pd.DataFrame(rows)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('checkpoint')
    ap.add_argument('--out', required=True)
    ap.add_argument('--device', default='cpu')
    args = ap.parse_args()
    df = retroactive_causal_trajectory(args.checkpoint, args.device)
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(out, index=False)
    print(out)


if __name__ == '__main__':
    main()
