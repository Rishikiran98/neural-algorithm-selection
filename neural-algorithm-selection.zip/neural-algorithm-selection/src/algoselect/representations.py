from __future__ import annotations

import cmath
from collections import OrderedDict

import numpy as np
import torch

from .groups import FiniteGroup


def characters(group: FiniteGroup):
    """Return name -> (complex dimension, character values in element order)."""
    if group.name == "D8":
        out = OrderedDict()
        for a in (1, -1):
            for b in (1, -1):
                vals = np.array([(a ** r) * (b ** s) for r, s in group.elements], dtype=np.complex128)
                out[f"chi_r{a:+d}_s{b:+d}"] = (1, vals)
        vals2 = [
            2 * np.cos(np.pi * r / 2) if s == 0 else 0.0
            for r, s in group.elements
        ]
        out["rho2_real"] = (2, np.asarray(vals2, dtype=np.complex128))
        return out

    if group.name == "Q8":
        out = OrderedDict()
        # All 1D characters factor through Q8/{+/-1} ~= C2 x C2.
        # Choose values a=chi(i), b=chi(j), hence chi(k)=ab and chi(-1)=1.
        for a in (1, -1):
            for b in (1, -1):
                vals = []
                for sign, basis in group.elements:
                    base_val = {"1": 1, "i": a, "j": b, "k": a * b}[basis]
                    vals.append(base_val)  # central -1 maps to +1 in every 1D irrep
                out[f"chi_i{a:+d}_j{b:+d}"] = (1, np.asarray(vals, dtype=np.complex128))
        vals2 = []
        for sign, basis in group.elements:
            if basis == "1":
                vals2.append(2.0 * sign)
            else:
                vals2.append(0.0)
        out["rho2_quaternionic"] = (2, np.asarray(vals2, dtype=np.complex128))
        return out

    if group.name == "H27":
        omega = cmath.exp(2j * cmath.pi / 3)
        out = OrderedDict()
        for a in range(3):
            for b in range(3):
                vals = np.array(
                    [omega ** ((a * x + b * y) % 3) for x, y, z in group.elements],
                    dtype=np.complex128,
                )
                out[f"chi_{a}_{b}"] = (1, vals)
        for k in (1, 2):
            vals = []
            for x, y, z in group.elements:
                vals.append(3 * (omega ** ((k * z) % 3)) if x == 0 and y == 0 else 0.0)
            out[f"rho3_k{k}"] = (3, np.asarray(vals, dtype=np.complex128))
        return out

    if group.name == "M27":
        zeta3 = cmath.exp(2j * cmath.pi / 3)
        zeta9 = cmath.exp(2j * cmath.pi / 9)
        out = OrderedDict()
        # Linear characters factor through the abelianization C3 x C3.
        for u in range(3):
            for v in range(3):
                vals = np.array(
                    [zeta3 ** ((u * (i % 3) + v * j) % 3) for i, j in group.elements],
                    dtype=np.complex128,
                )
                out[f"chi_{u}_{v}"] = (1, vals)
        # Two degree-3 irreps induced from the two size-3 orbits of non-fixed
        # characters of <a> ~= C9 under k -> 4k mod 9.
        for idx, orbit in enumerate(((1, 4, 7), (2, 8, 5)), start=1):
            vals = []
            for i, j in group.elements:
                if j != 0:
                    vals.append(0.0)
                else:
                    vals.append(sum(zeta9 ** ((k * i) % 9) for k in orbit))
            out[f"rho3_orbit{idx}"] = (3, np.asarray(vals, dtype=np.complex128))
        return out

    raise NotImplementedError(f"Characters not implemented for {group.name}")


def frobenius_schur_indicators(group: FiniteGroup):
    """Compute nu(chi)=|G|^-1 sum_g chi(g^2) for each irreducible character."""
    out = {}
    for name, (_, chi) in characters(group).items():
        val = 0j
        for g in group.elements:
            val += chi[group.index[group.mul(g, g)]]
        val /= group.order
        if abs(val.imag) < 1e-10 and abs(val.real - round(val.real)) < 1e-10:
            val = int(round(val.real))
        out[name] = val
    return out


def character_inner_products(group: FiniteGroup):
    chars = characters(group)
    names = list(chars)
    mat = np.zeros((len(names), len(names)), dtype=np.complex128)
    for i, a in enumerate(names):
        xa = chars[a][1]
        for j, b in enumerate(names):
            xb = chars[b][1]
            mat[i, j] = np.vdot(xa, xb) / group.order
    return names, mat


def left_regular(group: FiniteGroup, g):
    n = group.order
    L = np.zeros((n, n), dtype=np.complex128)
    for j, h in enumerate(group.elements):
        i = group.index[group.mul(g, h)]
        L[i, j] = 1.0
    return L


def central_projectors(group: FiniteGroup):
    chars = characters(group)
    mats = {g: left_regular(group, g) for g in group.elements}
    out = OrderedDict()
    for name, (d, chi) in chars.items():
        P = np.zeros((group.order, group.order), dtype=np.complex128)
        for idx, g in enumerate(group.elements):
            inv_idx = group.index[group.inv(g)]
            P += chi[inv_idx] * mats[g]
        P *= d / group.order
        P[np.abs(P) < 1e-12] = 0
        out[name] = P
    return out


def real_isotypic_blocks(group: FiniteGroup, atol: float = 1e-9):
    """Return real-stable central projector blocks.

    Real irreps remain individual blocks. Complex conjugate irreps are paired.
    Quaternionic irreps already have real-valued central idempotents and remain one
    block, though a faithful real realization has doubled real dimension.
    """
    chars = characters(group)
    projectors = central_projectors(group)
    remaining = list(chars)
    used = set()
    blocks = OrderedDict()
    for name in remaining:
        if name in used:
            continue
        _, chi = chars[name]
        if np.max(np.abs(chi.imag)) <= atol:
            blocks[name] = projectors[name].real
            used.add(name)
            continue
        partner = None
        for other in remaining:
            if other == name or other in used:
                continue
            if np.allclose(chars[other][1], np.conjugate(chi), atol=atol):
                partner = other
                break
        if partner is None:
            raise ValueError(f"Could not find conjugate character for {name} in {group.name}")
        block_name = f"{name}+{partner}"
        P = projectors[name] + projectors[partner]
        if np.max(np.abs(P.imag)) > 1e-7:
            raise ValueError(f"Conjugate block {block_name} is not numerically real")
        blocks[block_name] = P.real
        used.add(name)
        used.add(partner)
    return blocks


def embedding_isotypic_energy(embedding: torch.Tensor, projectors: dict[str, np.ndarray], center: bool = True):
    """Fraction of table energy in each supplied projector block.

    embedding has shape [M, |G|, d]. Centering removes the trivial component, which
    makes this useful for feature-structure tracking. Set center=False when the
    trivial block itself is scientifically relevant.
    """
    e = embedding - embedding.mean(dim=1, keepdim=True) if center else embedding
    denom = (e.abs() ** 2).sum(dim=(1, 2)).clamp_min(1e-12)
    out = {}
    for name, p_np in projectors.items():
        p = torch.as_tensor(p_np, device=e.device, dtype=e.dtype)
        proj = torch.einsum("gh,mhd->mgd", p, e)
        num = (proj.abs() ** 2).sum(dim=(1, 2))
        out[name] = (num / denom).detach().cpu()
    return out


def ablate_group_component(embedding: torch.Tensor, projector: np.ndarray):
    p = torch.as_tensor(projector, device=embedding.device, dtype=embedding.dtype)
    projected = torch.einsum("gh,mhd->mgd", p, embedding)
    return embedding - projected
