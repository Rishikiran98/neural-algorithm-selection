from __future__ import annotations

from dataclasses import dataclass
from itertools import product
from typing import Callable, Hashable, Sequence

Element = Hashable


@dataclass(frozen=True)
class FiniteGroup:
    name: str
    elements: tuple[Element, ...]
    mul_fn: Callable[[Element, Element], Element]
    identity: Element

    def __post_init__(self):
        object.__setattr__(self, "index", {g: i for i, g in enumerate(self.elements)})

    @property
    def order(self) -> int:
        return len(self.elements)

    def mul(self, a: Element, b: Element) -> Element:
        return self.mul_fn(a, b)

    def inv(self, a: Element) -> Element:
        for b in self.elements:
            if self.mul(a, b) == self.identity and self.mul(b, a) == self.identity:
                return b
        raise ValueError(f"No inverse for {a}")

    def table(self) -> list[list[int]]:
        return [[self.index[self.mul(a, b)] for b in self.elements] for a in self.elements]

    def element_order(self, a: Element) -> int:
        x = self.identity
        for k in range(1, self.order + 1):
            x = self.mul(x, a)
            if x == self.identity:
                return k
        raise ValueError("Element order exceeds group order")

    def center(self) -> tuple[Element, ...]:
        """Return the center Z(G) in the group's canonical element order."""
        return tuple(
            g for g in self.elements
            if all(self.mul(g, h) == self.mul(h, g) for h in self.elements)
        )

    def center_quotient_labels(self) -> tuple[int, ...]:
        """Map each element index to its coset in G/Z(G).

        Labels are deterministic: cosets are created in the order their first
        representative appears in ``self.elements``.
        """
        z = self.center()
        labels: dict[Element, int] = {}
        next_label = 0
        for g in self.elements:
            if g in labels:
                continue
            coset = {self.mul(g, c) for c in z}
            for h in coset:
                labels[h] = next_label
            next_label += 1
        return tuple(labels[g] for g in self.elements)


def d8() -> FiniteGroup:
    # (r, s) represents r^r s^s, with s r s = r^{-1}.
    elems = tuple((r, s) for r in range(4) for s in range(2))

    def mul(a, b):
        r, s = a
        rp, sp = b
        return ((r + ((-1) ** s) * rp) % 4, (s + sp) % 2)

    return FiniteGroup("D8", elems, mul, (0, 0))


def q8() -> FiniteGroup:
    # Elements are sign * basis, basis in {1, i, j, k}. Encoded (sign, basis).
    bases = ("1", "i", "j", "k")
    elems = tuple((sgn, b) for sgn in (1, -1) for b in bases)
    pos = {
        ("1", "1"): (1, "1"), ("1", "i"): (1, "i"), ("1", "j"): (1, "j"), ("1", "k"): (1, "k"),
        ("i", "1"): (1, "i"), ("j", "1"): (1, "j"), ("k", "1"): (1, "k"),
        ("i", "i"): (-1, "1"), ("j", "j"): (-1, "1"), ("k", "k"): (-1, "1"),
        ("i", "j"): (1, "k"), ("j", "k"): (1, "i"), ("k", "i"): (1, "j"),
        ("j", "i"): (-1, "k"), ("k", "j"): (-1, "i"), ("i", "k"): (-1, "j"),
    }

    def mul(a, b):
        sa, ba = a
        sb, bb = b
        s, base = pos[(ba, bb)]
        return (sa * sb * s, base)

    return FiniteGroup("Q8", elems, mul, (1, "1"))


def h27() -> FiniteGroup:
    # Heisenberg group over F_3. Law chosen to match rho(x,y,z)=omega^(kz) P^x Q^y,
    # where QP = omega PQ: z accumulates y*x'.
    elems = tuple(product(range(3), repeat=3))

    def mul(a, b):
        x, y, z = a
        xp, yp, zp = b
        return ((x + xp) % 3, (y + yp) % 3, (z + zp + y * xp) % 3)

    return FiniteGroup("H27", elems, mul, (0, 0, 0))


def m27() -> FiniteGroup:
    # Non-abelian semidirect product C9 ⋊ C3 with action b a b^-1 = a^4.
    # Elements are a^i b^j and (i,j)(k,l)=(i+4^j k, j+l).
    elems = tuple((i, j) for i in range(9) for j in range(3))

    def mul(a, b):
        i, j = a
        k, l = b
        return ((i + pow(4, j, 9) * k) % 9, (j + l) % 3)

    return FiniteGroup("M27", elems, mul, (0, 0))


def make_group(name: str) -> FiniteGroup:
    key = name.lower().replace("_", "").replace("-", "")
    mapping = {"d8": d8, "q8": q8, "h27": h27, "m27": m27}
    if key not in mapping:
        raise KeyError(f"Unknown group {name}. Choose from {sorted(mapping)}")
    return mapping[key]()
