"""Neural algorithm selection experiments."""

from .groups import make_group
