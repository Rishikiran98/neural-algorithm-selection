from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib.pyplot as plt
import pandas as pd


def plot_exact_vs_quotient(retro_metrics_csv: str | Path, out_path: str | Path, title: str):
    df = pd.read_csv(retro_metrics_csv)
    agg = df.groupby('step').agg(
        exact=('test_acc', 'mean'),
        quotient=('test_quotient_acc', 'mean'),
        fiber=('test_exact_given_quotient', 'mean'),
    ).reset_index()
    fig, ax = plt.subplots()
    ax.plot(agg.step, agg.exact, marker='o', label='exact held-out accuracy')
    ax.plot(agg.step, agg.quotient, marker='o', label='G/Z(G) held-out accuracy')
    ax.plot(agg.step, agg.fiber, marker='o', label='exact | correct quotient')
    ax.set_xlabel('training step')
    ax.set_ylabel('accuracy')
    ax.set_ylim(-0.02, 1.02)
    ax.set_title(title)
    ax.legend()
    fig.tight_layout()
    fig.savefig(out_path, dpi=180)
    plt.close(fig)


def plot_matched_quotient(h27_csv: str | Path, m27_csv: str | Path, out_path: str | Path):
    fig, ax = plt.subplots()
    for label, path in [('H27', h27_csv), ('M27', m27_csv)]:
        df = pd.read_csv(path)
        agg = df.groupby('step').test_quotient_acc.mean().reset_index()
        ax.plot(agg.step, agg.test_quotient_acc, marker='o', label=label)
    ax.set_xlabel('training step')
    ax.set_ylabel('mean held-out quotient accuracy')
    ax.set_ylim(-0.02, 1.02)
    ax.set_title('Matched order-27 groups learn the center quotient early')
    ax.legend()
    fig.tight_layout()
    fig.savefig(out_path, dpi=180)
    plt.close(fig)


def plot_causal_quotient(causal_csv: str | Path, out_path: str | Path, title: str):
    df = pd.read_csv(causal_csv)
    last = df[df.step == df.step.max()]
    agg = last.groupby('component').test_quotient_acc_delta.mean().sort_values()
    fig, ax = plt.subplots()
    ax.barh(agg.index, agg.values)
    ax.axvline(0, linewidth=1)
    ax.set_xlabel('change in held-out quotient accuracy after ablation')
    ax.set_title(title)
    fig.tight_layout()
    fig.savefig(out_path, dpi=180)
    plt.close(fig)


def plot_causal_train_loss(causal_csv: str | Path, out_path: str | Path, title: str):
    df = pd.read_csv(causal_csv)
    last = df[df.step == df.step.max()]
    agg = last.groupby('component').train_loss_delta.mean().sort_values()
    fig, ax = plt.subplots()
    ax.barh(agg.index, agg.values)
    ax.axvline(0, linewidth=1)
    ax.set_xlabel('change in training loss after ablation')
    ax.set_title(title)
    fig.tight_layout()
    fig.savefig(out_path, dpi=180)
    plt.close(fig)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--h27-metrics', required=True)
    ap.add_argument('--m27-metrics', required=True)
    ap.add_argument('--h27-causal', required=True)
    ap.add_argument('--m27-causal', required=True)
    ap.add_argument('--out-dir', required=True)
    args = ap.parse_args()
    out = Path(args.out_dir); out.mkdir(parents=True, exist_ok=True)
    plot_exact_vs_quotient(args.h27_metrics, out/'h27_exact_vs_quotient.png', 'H27: quotient learning precedes exact composition')
    plot_exact_vs_quotient(args.m27_metrics, out/'m27_exact_vs_quotient.png', 'M27: quotient learning precedes exact composition')
    plot_matched_quotient(args.h27_metrics, args.m27_metrics, out/'matched_quotient_comparison.png')
    plot_causal_quotient(args.h27_causal, out/'h27_causal_quotient.png', 'H27: causal effect of representation-block ablation')
    plot_causal_train_loss(args.h27_causal, out/'h27_causal_train_loss.png', 'H27: which blocks support memorization?')
    plot_causal_quotient(args.m27_causal, out/'m27_causal_quotient.png', 'M27: causal effect of representation-block ablation')
    plot_causal_train_loss(args.m27_causal, out/'m27_causal_train_loss.png', 'M27: which blocks support memorization?')


if __name__ == '__main__':
    main()
