from __future__ import annotations

import argparse
import json
from itertools import combinations
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from .screen import summarize_metrics, summarize_structure


def make_accuracy_plot(metrics_path: str | Path, out_path: str | Path):
    df = pd.read_csv(metrics_path)
    agg = df.groupby('step').agg(
        mean_train_acc=('train_acc', 'mean'),
        mean_test_acc=('test_acc', 'mean'),
    ).reset_index()
    fig, ax = plt.subplots()
    ax.plot(agg.step, agg.mean_train_acc, label='mean train accuracy')
    ax.plot(agg.step, agg.mean_test_acc, label='mean held-out accuracy', linestyle='--')
    ax.set_xlabel('training step')
    ax.set_ylabel('accuracy')
    ax.set_ylim(-0.02, 1.02)
    ax.set_title('Memorization and held-out generalization')
    ax.legend()
    fig.tight_layout()
    fig.savefig(out_path, dpi=180)
    plt.close(fig)


def make_structure_plot(structure_summary_path: str | Path, out_path: str | Path):
    df = pd.read_csv(structure_summary_path)
    model_step = df.groupby(['model', 'step']).structure_score.max().reset_index()
    agg = model_step.groupby('step').agg(
        mean_structure_score=('structure_score', 'mean'),
        max_structure_score=('structure_score', 'max'),
    ).reset_index()
    _, summary = summarize_structure(structure_summary_path)

    fig, ax = plt.subplots()
    ax.plot(agg.step, agg.mean_structure_score, label='mean structure score')
    ax.plot(agg.step, agg.max_structure_score, label='max seed structure score', linestyle='--')
    ax.axhline(summary['structure_threshold'], label='onset threshold', linestyle=':')
    ax.set_xlabel('training step')
    ax.set_ylabel('deviation from isotropic irrep energy')
    ax.set_title('Representation concentration after memorization')
    ax.legend()
    fig.tight_layout()
    fig.savefig(out_path, dpi=180)
    plt.close(fig)


def _js_divergence(p: np.ndarray, q: np.ndarray, eps: float = 1e-12) -> float:
    p = np.asarray(p, dtype=float)
    q = np.asarray(q, dtype=float)
    p = np.clip(p, eps, None)
    q = np.clip(q, eps, None)
    p = p / p.sum()
    q = q / q.sum()
    m = 0.5 * (p + q)
    return float(0.5 * np.sum(p * np.log(p / m)) + 0.5 * np.sum(q * np.log(q / m)))


def mechanism_fingerprints(structure_path: str | Path) -> pd.DataFrame:
    """Build rank-corrected mechanism fingerprints from irrep energy trajectories.

    Raw isotypic energy is not directly comparable across blocks because the
    isotropic expectation scales with projector rank. We therefore compute an
    enrichment ratio energy / E_isotropic for every nontrivial block, average
    enrichment across left/right/unembedding, and renormalize across blocks.
    The resulting vector is uniform at isotropic initialization and highlights
    relative representation preference rather than block size.
    """
    df = pd.read_csv(structure_path)
    required = {
        'model', 'step', 'table', 'block', 'energy', 'isotropic_expected_energy'
    }
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"structure trajectory missing columns: {sorted(missing)}")

    x = df[df.isotropic_expected_energy > 0].copy()
    if x.empty:
        raise ValueError('no nontrivial blocks with positive isotropic expectation')
    x['enrichment'] = x.energy / x.isotropic_expected_energy.clip(lower=1e-12)
    avg = (
        x.groupby(['model', 'step', 'block'], as_index=False)
        .agg(
            mean_energy=('energy', 'mean'),
            isotropic_expected_energy=('isotropic_expected_energy', 'first'),
            enrichment=('enrichment', 'mean'),
        )
    )
    denom = avg.groupby(['model', 'step']).enrichment.transform('sum').clip(lower=1e-12)
    avg['fingerprint_weight'] = avg.enrichment / denom
    avg['log_enrichment'] = np.log(avg.enrichment.clip(lower=1e-12))
    return avg.sort_values(['model', 'step', 'block']).reset_index(drop=True)


def seed_divergence(fingerprints: pd.DataFrame) -> pd.DataFrame:
    rows = []
    blocks = sorted(fingerprints.block.unique())
    for step, g in fingerprints.groupby('step'):
        pivot = g.pivot(index='model', columns='block', values='fingerprint_weight').reindex(columns=blocks)
        models = list(pivot.index)
        pair_vals = []
        for a, b in combinations(models, 2):
            js = _js_divergence(pivot.loc[a].to_numpy(), pivot.loc[b].to_numpy())
            pair_vals.append(js)
            rows.append({
                'step': int(step), 'model_a': int(a), 'model_b': int(b),
                'js_divergence': js, 'record_type': 'pair',
            })
        if pair_vals:
            rows.append({
                'step': int(step), 'model_a': -1, 'model_b': -1,
                'js_divergence': float(np.mean(pair_vals)), 'record_type': 'mean_pairwise',
            })
    return pd.DataFrame(rows)


def fingerprint_drift(fingerprints: pd.DataFrame) -> pd.DataFrame:
    blocks = sorted(fingerprints.block.unique())
    first_step = int(fingerprints.step.min())
    base = fingerprints[fingerprints.step == first_step].pivot(
        index='model', columns='block', values='fingerprint_weight'
    ).reindex(columns=blocks)
    rows = []
    for (model, step), g in fingerprints.groupby(['model', 'step']):
        cur = g.set_index('block').reindex(blocks).fingerprint_weight.to_numpy()
        js = _js_divergence(base.loc[model].to_numpy(), cur)
        rows.append({'model': int(model), 'step': int(step), 'js_from_init': js})
    return pd.DataFrame(rows)


def make_seed_divergence_plot(
    fingerprints: pd.DataFrame,
    out_path: str | Path,
    metrics_path: str | Path | None = None,
):
    div = seed_divergence(fingerprints)
    drift = fingerprint_drift(fingerprints)
    mean_pair = div[div.record_type == 'mean_pairwise']
    drift_agg = drift.groupby('step').js_from_init.mean().reset_index()

    fig, ax = plt.subplots()
    if not mean_pair.empty:
        ax.plot(mean_pair.step, mean_pair.js_divergence, label='mean pairwise seed divergence')
    ax.plot(drift_agg.step, drift_agg.js_from_init, label='mean drift from initialization', linestyle='--')
    if metrics_path is not None:
        per, _ = summarize_metrics(metrics_path)
        t_mem = per.t_mem.dropna()
        t_gen = per.t_gen.dropna()
        if not t_mem.empty:
            ax.axvline(float(t_mem.median()), linestyle=':', label='median memorization')
        if not t_gen.empty:
            ax.axvline(float(t_gen.median()), linestyle='-.', label='median generalization')
    ax.set_xlabel('training step')
    ax.set_ylabel('Jensen-Shannon divergence (nats)')
    ax.set_title('Seed-level mechanism fingerprint separation')
    ax.legend()
    fig.tight_layout()
    fig.savefig(out_path, dpi=180)
    plt.close(fig)
    return div, drift


def summarize_run(
    metrics_path: str | Path,
    structure_summary_path: str | Path,
    out_path: str | Path,
    structure_path: str | Path | None = None,
):
    _, metrics = summarize_metrics(metrics_path)
    _, structure = summarize_structure(structure_summary_path)
    summary = {**metrics, **structure}
    if structure_path is not None:
        fp = mechanism_fingerprints(structure_path)
        div = seed_divergence(fp)
        drift = fingerprint_drift(fp)
        mean_pair = div[div.record_type == 'mean_pairwise']
        if not mean_pair.empty:
            summary['final_mean_pairwise_seed_js'] = float(mean_pair.sort_values('step').iloc[-1].js_divergence)
            summary['max_mean_pairwise_seed_js'] = float(mean_pair.js_divergence.max())
        last_step = int(drift.step.max())
        summary['final_mean_js_from_init'] = float(drift[drift.step == last_step].js_from_init.mean())
    Path(out_path).write_text(json.dumps(summary, indent=2))
    return summary


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--metrics', required=True)
    ap.add_argument('--structure-summary', required=True)
    ap.add_argument('--structure')
    ap.add_argument('--out-dir', required=True)
    args = ap.parse_args()

    out = Path(args.out_dir)
    out.mkdir(parents=True, exist_ok=True)
    make_accuracy_plot(args.metrics, out / 'accuracy.png')
    make_structure_plot(args.structure_summary, out / 'structure.png')
    if args.structure:
        fp = mechanism_fingerprints(args.structure)
        fp.to_csv(out / 'mechanism_fingerprints.csv', index=False)
        div, drift = make_seed_divergence_plot(fp, out / 'seed_divergence.png', args.metrics)
        div.to_csv(out / 'seed_divergence.csv', index=False)
        drift.to_csv(out / 'fingerprint_drift.csv', index=False)
    summary = summarize_run(
        args.metrics,
        args.structure_summary,
        out / 'summary.json',
        structure_path=args.structure,
    )
    print(json.dumps(summary, indent=2))


if __name__ == '__main__':
    main()
