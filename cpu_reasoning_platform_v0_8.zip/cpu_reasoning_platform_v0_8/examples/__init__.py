"""Local examples."""
