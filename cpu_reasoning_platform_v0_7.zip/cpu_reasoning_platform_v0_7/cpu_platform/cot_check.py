"""Conservative arithmetic checks over *visible, free-form* reasoning text.

Not a semantic proof. Only explicit equations using + - * / and numerical
literals are checkable. A missing equation is NOT positive verification.
Never execute generated Python or arbitrary model text.
"""
from __future__ import annotations

from dataclasses import dataclass, asdict
from fractions import Fraction
import re

from cpu_first.core import exact_arithmetic, InvalidExpression, formatted_fraction, parse_number

# Only exact arithmetic claims using an equals sign are eligible. No evaluation
# of prose, function calls, percentages, unit conversions or implicit equations.
RHS = re.compile(r"\s*=\s*(?P<rhs>[+-]?\d+(?:\.\d+)?)(?![\w]|\.\d)")
NUMBER_START = re.compile(r"(?<![\w.])(?:\d+(?:\.\d+)?|\()")
OPERATORS = re.compile(r"[+\-*/]")
ALLOWED_LHS = re.compile(r"^[\d\s+\-*/().]+$")
MAP = str.maketrans({"×": "*", "÷": "/", "−": "-", "–": "-", "·": "*"})
MAX_TEXT = 12000
MAX_EQUATIONS = 40


@dataclass(frozen=True)
class Equation:
    expression: str
    claimed: str
    actual: str | None
    correct: bool | None


@dataclass(frozen=True)
class Audit:
    status: str    # checked_pass | arithmetic_error | no_checkable_equations
    checked_count: int
    error_count: int
    equations: tuple[Equation, ...]
    truncated: bool

    def to_dict(self) -> dict:
        return asdict(self)


def _candidate_lhs(prefix: str) -> tuple[str, Fraction] | None:
    """Longest valid suffix of text preceding '=' (bounded to 200 chars)."""
    part = prefix[-200:].translate(MAP)
    # Hard delimiters: do not reach into previous sentences / lines.
    part = re.split(r"[\n;:=!?]", part)[-1]
    options: list[tuple[int, str, Fraction]] = []
    for start in NUMBER_START.finditer(part):
        candidate = part[start.start():].strip()
        if not candidate or not ALLOWED_LHS.fullmatch(candidate):
            continue
        if not OPERATORS.search(candidate):
            continue
        try:
            result = exact_arithmetic(candidate)
        except (InvalidExpression, ValueError, ZeroDivisionError):
            continue
        options.append((len(candidate), candidate, result))
    if not options:
        return None
    _, expression, value = max(options, key=lambda c: c[0])
    return expression, value


def audit_reasoning(content: str) -> Audit:
    """Check every recognized equation; not a general language verifier.

    Unsupported forms are not counted as successes. To avoid misleading claims,
    only returns checked_pass if at least one arithmetic equation was checked.
    """
    normalized = content[:MAX_TEXT] if isinstance(content, str) else ""
    found: list[Equation] = []
    for match in RHS.finditer(normalized):
        if len(found) >= MAX_EQUATIONS:
            break
        lhs = _candidate_lhs(normalized[max(0, match.start() - 200):match.start()])
        if lhs is None:
            continue
        expression, value = lhs
        try:
            claimed = parse_number(match.group("rhs"))
        except (ValueError, TypeError):
            continue
        found.append(Equation(expression, formatted_fraction(claimed),
                              formatted_fraction(value), value == claimed))
    errors = sum(eq.correct is False for eq in found)
    status = "arithmetic_error" if errors else ("checked_pass" if found else "no_checkable_equations")
    return Audit(status, len(found), errors, tuple(found),
                 len(normalized) >= MAX_TEXT or len(found) >= MAX_EQUATIONS)
