"""CPU-native verifiable reasoning research preview, version 0.7.0."""
__version__ = "0.7.0"
